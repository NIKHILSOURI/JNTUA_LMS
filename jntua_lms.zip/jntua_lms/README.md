# JNTUA Faculty Leave Management System

## Chapter 3: Design

### 3.1 Page Structure

#### 1. Authentication Pages
- **index.php**: Main login page
  - User role selection (Admin/Faculty)
  - Username/password authentication
  - Error message display
  - Session management

#### 2. Admin Portal Pages
- **admin/dashboard.php**: Admin control panel
  - Overview statistics
  - Quick access to main functions
  - System status summary

- **admin/employees.php**: Employee management
  - List all faculty members
  - View employee details
  - Search and filter options

- **admin/add-employee.php**: New employee registration
  - Personal information input
  - Department assignment
  - Designation selection
  - Account credentials creation
  - Leave balance initialization

- **admin/applications.php**: Leave application management
  - View all leave applications
  - Filter by status/department
  - Approve/Reject applications
  - View application details

- **admin/departments.php**: Department management
  - List all departments
  - Add/Edit departments
  - Department code management

- **admin/designations.php**: Designation management
  - List all designations
  - Add/Edit designations

- **admin/leave-types.php**: Leave type configuration
  - Define leave categories
  - Set maximum days
  - Edit leave policies

- **admin/reports.php**: Reporting system
  - Generate leave reports
  - Department-wise statistics
  - Custom date range reports

#### 3. Faculty Portal Pages
- **faculty/dashboard.php**: Faculty homepage
  - Personal information display
  - Leave balance summary
  - Recent applications
  - Quick action buttons
  - Application statistics

- **faculty/apply-leave.php**: Leave application
  - Leave type selection
  - Date range picker
  - Reason input
  - Document attachment
  - Balance verification

- **faculty/applications.php**: Application history
  - List personal applications
  - View application status
  - Cancel pending applications

- **faculty/profile.php**: Profile management
  - View personal details
  - Update contact information
  - Change password

- **faculty/notifications.php**: Alert system
  - Application status updates
  - System notifications
  - Unread notification counter

### 3.2 Database Structure

#### Tables
1. **users**
   - Authentication and role management
   - User credentials and status

2. **employees**
   - Faculty personal information
   - Department and designation mapping
   - Contact details

3. **departments**
   - Department information
   - Unique department codes

4. **designations**
   - Faculty position types
   - Hierarchy management

5. **leave_types**
   - Leave categories
   - Maximum days allowed
   - Policy definitions

6. **leave_applications**
   - Application tracking
   - Status management
   - Date and duration details

7. **leave_balances**
   - Leave quota tracking
   - Year-wise balance management
   - Used leave counting

8. **notifications**
   - System alerts
   - Status change notifications
   - User communication

## Chapter 4: Implementation

### 4.1 Technical Details

#### Technology Stack
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **Frontend**: HTML5, CSS3, JavaScript
- **UI Framework**: Custom CSS with FontAwesome icons
- **Security**: Prepared statements, Password hashing
- **Session Management**: PHP Sessions

#### Key Features Implementation

1. **Authentication System**
   - Role-based access control
   - Secure password hashing
   - Session management
   - Login attempt tracking

2. **Employee Management**
   - Unique employee ID generation
   - Department-wise organization
   - Profile management
   - Account status control

3. **Leave Management**
   - Automated balance calculation
   - Policy enforcement
   - Document attachment handling
   - Status tracking system

4. **Notification System**
   - Real-time status updates
   - Email notifications
   - Unread notification tracking
   - System alerts

5. **Reporting System**
   - Dynamic report generation
   - Multiple format support
   - Custom date range filtering
   - Department-wise analytics

#### Security Implementation
- SQL injection prevention
- XSS attack protection
- CSRF token validation
- Secure file upload handling
- Password policy enforcement
- Session timeout management

#### Database Operations
- Transaction management
- Referential integrity
- Index optimization
- Query optimization
- Backup procedures

#### Error Handling
- Custom error pages
- Error logging system
- User-friendly messages
- Debug mode toggle

### 4.2 Installation Requirements

1. **Server Requirements**
   - Apache/Nginx web server
   - PHP 7.4 or higher
   - MySQL 5.7 or higher
   - mod_rewrite enabled

2. **PHP Extensions**
   - mysqli
   - PDO
   - GD Library
   - FileInfo
   - Session

3. **Database Setup**
   - Import schema.sql
   - Configure database credentials
   - Initialize sample data

4. **File Permissions**
   - uploads/ directory (777)
   - logs/ directory (755)
   - config files (644)

### 4.3 Configuration

1. **Database Configuration**
   - Edit config/database.php
   - Set database credentials
   - Configure connection parameters

2. **Application Settings**
   - System email configuration
   - File upload settings
   - Session timeout values
   - Debug mode settings

3. **Security Settings**
   - Password policy configuration
   - Session security settings
   - File upload restrictions
   - API access controls 