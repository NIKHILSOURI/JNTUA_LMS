<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate input
    $errors = [];

    // Name validation
    $name = trim($_POST['name']);
    if (empty($name) || strlen($name) < 2) {
        $errors[] = "Name must be at least 2 characters long.";
    }

    // Email validation
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    if (!$email) {
        $errors[] = "Invalid email address.";
    }

    // Check if email already exists
    $email_check_sql = "SELECT id FROM employees WHERE email = ?";
    $stmt = mysqli_prepare($conn, $email_check_sql);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    if (mysqli_stmt_num_rows($stmt) > 0) {
        $errors[] = "Email already exists.";
    }
    mysqli_stmt_close($stmt);

    // Phone validation
    $phone = preg_replace('/[^0-9]/', '', $_POST['phone']);
    if (strlen($phone) != 10) {
        $errors[] = "Phone number must be 10 digits.";
    }

    // Department and Designation validation
    $department_id = filter_input(INPUT_POST, 'department_id', FILTER_VALIDATE_INT);
    $designation_id = filter_input(INPUT_POST, 'designation_id', FILTER_VALIDATE_INT);
    if (!$department_id) {
        $errors[] = "Invalid department selection.";
    }
    if (!$designation_id) {
        $errors[] = "Invalid designation selection.";
    }

    // Joining date validation
    $joining_date = $_POST['joining_date'];
    if (empty($joining_date) || strtotime($joining_date) === false) {
        $errors[] = "Invalid joining date.";
    }

    // Username validation
    $username = trim($_POST['username']);
    if (empty($username) || strlen($username) < 3) {
        $errors[] = "Username must be at least 3 characters long.";
    }

    // Check if username already exists
    $username_check_sql = "SELECT id FROM users WHERE username = ?";
    $stmt = mysqli_prepare($conn, $username_check_sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    if (mysqli_stmt_num_rows($stmt) > 0) {
        $errors[] = "Username already exists.";
    }
    mysqli_stmt_close($stmt);

    // Password validation
    $password = $_POST['password'];
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
    }

    // If there are validation errors, return to form
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        $_SESSION['form_data'] = $_POST;
        header("location: add-employee.php");
        exit();
    }

    // Start transaction
    mysqli_begin_transaction($conn);

    try {
        // Sanitize inputs
        $name = mysqli_real_escape_string($conn, $name);
        $email = mysqli_real_escape_string($conn, $email);
        $phone = mysqli_real_escape_string($conn, $phone);
        $username = mysqli_real_escape_string($conn, $username);
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        // Insert user account
        $user_sql = "INSERT INTO users (username, password, role, is_active) VALUES (?, ?, 'faculty', 1)";
        $stmt = mysqli_prepare($conn, $user_sql);
        mysqli_stmt_bind_param($stmt, "ss", $username, $password_hash);
        
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Failed to create user account: " . mysqli_stmt_error($stmt));
        }
        $user_id = mysqli_insert_id($conn);

        // Generate Employee ID
        $employee_id = generateEmployeeID($conn, $department_id);

        // Insert employee details
        $emp_sql = "INSERT INTO employees (user_id, employee_id, name, email, phone, department_id, designation_id, joining_date, created_at) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmt = mysqli_prepare($conn, $emp_sql);
        mysqli_stmt_bind_param($stmt, "issssiss", $user_id, $employee_id, $name, $email, $phone, $department_id, $designation_id, $joining_date);
        
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Failed to create employee record: " . mysqli_stmt_error($stmt));
        }
        $employee_record_id = mysqli_insert_id($conn);

        // Initialize leave balances for the new employee
        $year = date('Y');
        $leave_types_sql = "SELECT id, max_days FROM leave_types";
        $leave_types_result = mysqli_query($conn, $leave_types_sql);

        while($leave_type = mysqli_fetch_assoc($leave_types_result)) {
            $balance_sql = "INSERT INTO leave_balances (employee_id, leave_type_id, year, total_leaves, leaves_taken) 
                          VALUES (?, ?, ?, ?, 0)";
            $stmt = mysqli_prepare($conn, $balance_sql);
            mysqli_stmt_bind_param($stmt, "iiii", $employee_record_id, $leave_type['id'], $year, $leave_type['max_days']);
            
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Failed to create leave balance: " . mysqli_stmt_error($stmt));
            }
        }

        mysqli_commit($conn);
        $_SESSION['success'] = "Employee added successfully. Employee ID: " . $employee_id;
        header("location: employees.php");
        exit();
    } catch (Exception $e) {
        mysqli_rollback($conn);
        error_log("Employee addition error: " . $e->getMessage());
        $_SESSION['error'] = "Error adding employee: " . $e->getMessage();
        header("location: add-employee.php");
        exit();
    }
}

// Modify the form to show previous errors and form data
$form_data = $_SESSION['form_data'] ?? [];
$form_errors = $_SESSION['errors'] ?? [];
unset($_SESSION['form_data'], $_SESSION['errors']);

// Fetch departments and designations for dropdowns
$departments = mysqli_query($conn, "SELECT * FROM departments ORDER BY name");
$designations = mysqli_query($conn, "SELECT * FROM designations ORDER BY name");

// Generate Employee ID
function generateEmployeeID($conn, $department_id) {
    // Get department code
    $dept_code_sql = "SELECT code FROM departments WHERE id = ?";
    $stmt = mysqli_prepare($conn, $dept_code_sql);
    mysqli_stmt_bind_param($stmt, "i", $department_id);
    mysqli_stmt_execute($stmt);
    $dept_result = mysqli_stmt_get_result($stmt);
    $dept = mysqli_fetch_assoc($dept_result);
    
    if (!$dept) {
        throw new Exception("Department not found");
    }
    
    // Get current year
    $year = date('Y');
    
    // Count existing employees in this department
    $count_sql = "SELECT COUNT(*) as count FROM employees WHERE department_id = ?";
    $stmt = mysqli_prepare($conn, $count_sql);
    mysqli_stmt_bind_param($stmt, "i", $department_id);
    mysqli_stmt_execute($stmt);
    $count_result = mysqli_stmt_get_result($stmt);
    $count = mysqli_fetch_assoc($count_result);
    
    // Generate unique employee ID
    $sequence = str_pad($count['count'] + 1, 3, '0', STR_PAD_LEFT);
    return strtoupper($dept['code']) . $year . $sequence;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Admin Panel</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="employees.php" class="active"><i class="fas fa-users"></i> Employees List</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> Application List</a></li>
                <li><a href="departments.php"><i class="fas fa-building"></i> Department List</a></li>
                <li><a href="designations.php"><i class="fas fa-id-badge"></i> Designation List</a></li>
                <li><a href="leave-types.php"><i class="fas fa-calendar-alt"></i> Leave Type List</a></li>
                <li><a href="users.php"><i class="fas fa-user"></i> User List</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Add New Employee</h1>
            </div>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(!empty($form_errors)): ?>
                <div class="alert alert-error">
                    <ul>
                        <?php foreach($form_errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="content-wrapper">
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" required value="<?php echo $form_data['name'] ?? ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required value="<?php echo $form_data['email'] ?? ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" name="phone" required value="<?php echo $form_data['phone'] ?? ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="department_id">Department</label>
                        <select id="department_id" name="department_id" required>
                            <option value="">Select Department</option>
                            <?php while($dept = mysqli_fetch_assoc($departments)): ?>
                                <option value="<?php echo $dept['id']; ?>" <?php echo ($form_data['department_id'] ?? '') == $dept['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($dept['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="designation_id">Designation</label>
                        <select id="designation_id" name="designation_id" required>
                            <option value="">Select Designation</option>
                            <?php while($desig = mysqli_fetch_assoc($designations)): ?>
                                <option value="<?php echo $desig['id']; ?>" <?php echo ($form_data['designation_id'] ?? '') == $desig['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($desig['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="joining_date">Joining Date</label>
                        <input type="date" id="joining_date" name="joining_date" required value="<?php echo $form_data['joining_date'] ?? ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required value="<?php echo $form_data['username'] ?? ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Add Employee</button>
                        <a href="employees.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    document.getElementById('email').addEventListener('blur', function() {
        let username = this.value.split('@')[0];
        document.getElementById('username').value = username;
    });
    </script>
</body>
</html> 