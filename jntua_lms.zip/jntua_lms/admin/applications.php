<?php
session_start();
require_once '../config/database.php';
require_once '../includes/notification_functions.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Get filter values
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$department_filter = isset($_GET['department']) ? $_GET['department'] : '';
$from_date = isset($_GET['from_date']) ? $_GET['from_date'] : '';
$to_date = isset($_GET['to_date']) ? $_GET['to_date'] : '';

// Build query conditions
$conditions = [];
$params = [];
$types = '';

if($status_filter) {
    $conditions[] = "la.status = ?";
    $params[] = $status_filter;
    $types .= 's';
}

if($department_filter) {
    $conditions[] = "e.department_id = ?";
    $params[] = $department_filter;
    $types .= 'i';
}

if($from_date) {
    $conditions[] = "la.from_date >= ?";
    $params[] = $from_date;
    $types .= 's';
}

if($to_date) {
    $conditions[] = "la.to_date <= ?";
    $params[] = $to_date;
    $types .= 's';
}

// Fetch all leave applications with employee and leave type details
$sql = "SELECT la.*, e.name as employee_name, e.email as employee_email, 
               d.name as department_name, lt.name as leave_type,
               lt.requires_attachment 
        FROM leave_applications la 
        JOIN employees e ON la.employee_id = e.id 
        JOIN departments d ON e.department_id = d.id 
        JOIN leave_types lt ON la.leave_type_id = lt.id";

if(!empty($conditions)) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

$sql .= " ORDER BY la.created_at DESC";

$stmt = mysqli_prepare($conn, $sql);
if(!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Fetch departments for filter
$departments = mysqli_query($conn, "SELECT * FROM departments ORDER BY name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Applications - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Admin Panel</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="employees.php"><i class="fas fa-users"></i> Employees List</a></li>
                <li><a href="applications.php" class="active"><i class="fas fa-file-alt"></i> Application List</a></li>
                <li><a href="departments.php"><i class="fas fa-building"></i> Department List</a></li>
                <li><a href="designations.php"><i class="fas fa-id-badge"></i> Designation List</a></li>
                <li><a href="leave-types.php"><i class="fas fa-calendar-alt"></i> Leave Type List</a></li>
                <li><a href="users.php"><i class="fas fa-user"></i> User List</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Leave Applications</h1>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Filters -->
            <div class="filters">
                <form method="GET" class="filter-form">
                    <div class="filter-group">
                        <label for="status">Status:</label>
                        <select name="status" id="status">
                            <option value="">All Status</option>
                            <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="approved" <?php echo $status_filter == 'approved' ? 'selected' : ''; ?>>Approved</option>
                            <option value="rejected" <?php echo $status_filter == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="department">Department:</label>
                        <select name="department" id="department">
                            <option value="">All Departments</option>
                            <?php while($dept = mysqli_fetch_assoc($departments)): ?>
                                <option value="<?php echo $dept['id']; ?>" <?php echo $department_filter == $dept['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($dept['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="from_date">From Date:</label>
                        <input type="date" name="from_date" id="from_date" value="<?php echo $from_date; ?>">
                    </div>
                    <div class="filter-group">
                        <label for="to_date">To Date:</label>
                        <input type="date" name="to_date" id="to_date" value="<?php echo $to_date; ?>">
                    </div>
                    <div class="filter-actions">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="applications.php" class="btn btn-secondary">Reset</a>
                    </div>
                </form>
            </div>

            <div class="content-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Employee</th>
                            <th>Department</th>
                            <th>Leave Type</th>
                            <th>From Date</th>
                            <th>To Date</th>
                            <th>Days</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Applied On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <?php echo htmlspecialchars($row['employee_name']); ?><br>
                                    <small><?php echo htmlspecialchars($row['employee_email']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($row['department_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($row['from_date'])); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($row['to_date'])); ?></td>
                                <td><?php echo $row['days']; ?></td>
                                <td>
                                    <span class="tooltip" data-tooltip="<?php echo htmlspecialchars($row['reason']); ?>">
                                        <?php echo strlen($row['reason']) > 30 ? substr(htmlspecialchars($row['reason']), 0, 30) . '...' : htmlspecialchars($row['reason']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if($row['status'] == 'pending'): ?>
                                        <div class="action-buttons">
                                            <button onclick="approveApplication(<?php echo $row['id']; ?>)" class="btn btn-success btn-sm">
                                                <i class="fas fa-check"></i> Approve
                                            </button>
                                            <button onclick="rejectApplication(<?php echo $row['id']; ?>)" class="btn btn-danger btn-sm">
                                                <i class="fas fa-times"></i> Reject
                                            </button>
                                        </div>
                                    <?php else: ?>
                                        <span class="badge badge-<?php 
                                            echo $row['status'] == 'approved' ? 'success' : 
                                                ($row['status'] == 'rejected' ? 'danger' : 'warning'); 
                                        ?>">
                                            <?php echo ucfirst($row['status']); ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('Y-m-d H:i', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <?php if($row['attachment'] && $row['requires_attachment']): ?>
                                        <a href="../view-attachment.php?file=<?php echo urlencode($row['attachment']); ?>" class="btn btn-info btn-sm" target="_blank" title="View Attachment">
                                            <i class="fas fa-paperclip"></i>
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <style>
    .filters {
        background: #fff;
        padding: 20px;
        margin-bottom: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .filter-form {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        align-items: flex-end;
    }
    .filter-group {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }
    .filter-actions {
        display: flex;
        gap: 10px;
    }
    .tooltip {
        position: relative;
        cursor: pointer;
    }
    .tooltip:hover:after {
        content: attr(data-tooltip);
        position: absolute;
        bottom: 100%;
        left: 50%;
        transform: translateX(-50%);
        background: #333;
        color: white;
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 1;
    }
    .badge-warning {
        background-color: #ffc107;
        color: #000;
    }
    </style>

    <script>
    function approveApplication(id) {
        if(confirm('Are you sure you want to approve this leave application?')) {
            window.location.href = `process_leave.php?id=${id}&action=approve`;
        }
    }

    function rejectApplication(id) {
        const remarks = prompt('Please enter rejection remarks:');
        if(remarks !== null && remarks.trim() !== '') {
            window.location.href = `process_leave.php?id=${id}&action=reject&remarks=${encodeURIComponent(remarks)}`;
        } else if(remarks !== null) {
            alert('Remarks are required for rejection.');
        }
    }
    </script>
</body>
</html> 