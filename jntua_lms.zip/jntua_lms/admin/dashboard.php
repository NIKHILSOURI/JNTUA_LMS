<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Current year and month
$current_year = date('Y');
$current_month = date('m');

// Key Metrics Queries
$metrics_queries = [
    'total_employees' => "SELECT COUNT(*) as count FROM employees",
    'total_departments' => "SELECT COUNT(*) as count FROM departments",
    'total_leave_applications' => "SELECT COUNT(*) as count FROM leave_applications",
    'pending_applications' => "SELECT COUNT(*) as count FROM leave_applications WHERE status = 'pending'",
    
    'monthly_leave_applications' => "
        SELECT 
            COUNT(*) as total_applications,
            SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_applications,
            SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_applications
        FROM leave_applications
        WHERE YEAR(from_date) = $current_year AND MONTH(from_date) = $current_month
    ",
    
    'leave_type_distribution' => "
        SELECT 
            lt.name as leave_type,
            COUNT(la.id) as total_applications,
            SUM(la.days) as total_days
        FROM leave_types lt
        LEFT JOIN leave_applications la ON lt.id = la.leave_type_id
        WHERE YEAR(la.from_date) = $current_year
        GROUP BY lt.id, lt.name
    ",
    
    'department_leave_stats' => "
        SELECT 
            d.name as department,
            COUNT(la.id) as total_applications,
            SUM(la.days) as total_days
        FROM departments d
        LEFT JOIN employees e ON d.id = e.department_id
        LEFT JOIN leave_applications la ON e.id = la.employee_id
        WHERE YEAR(la.from_date) = $current_year
        GROUP BY d.id, d.name
        ORDER BY total_applications DESC
        LIMIT 5
    "
];

// Execute queries and store results
$metrics = [];
foreach ($metrics_queries as $key => $query) {
    $result = mysqli_query($conn, $query);
    $metrics[$key] = ($key === 'leave_type_distribution' || $key === 'department_leave_stats') 
        ? mysqli_fetch_all($result, MYSQLI_ASSOC) 
        : mysqli_fetch_assoc($result);
}

// Prepare data for charts
$leave_type_labels = array_column($metrics['leave_type_distribution'], 'leave_type');
$leave_type_apps = array_column($metrics['leave_type_distribution'], 'total_applications');
$leave_type_days = array_column($metrics['leave_type_distribution'], 'total_days');

$dept_labels = array_column($metrics['department_leave_stats'], 'department');
$dept_apps = array_column($metrics['department_leave_stats'], 'total_applications');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color:#003366;
            --secondary-color:rgb(2, 132, 197);
            --accent-color:rgb(255, 255, 255);
            --background-light:rgb(201, 237, 255);
            --text-dark:rgb(0, 33, 65);
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .metric-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: center;
            box-shadow: 0 6px 12px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .metric-card:hover {
            transform: translateY(-5px);
        }

        .metric-icon {
            font-size: 3rem;
            margin-right: 15px;
            opacity: 0.7;
        }

        .metric-content {
            flex-grow: 1;
        }

        .metric-title {
            font-size: 0.9rem;
            color: var(--text-dark);
            margin-bottom: 5px;
            text-transform: uppercase;
        }

        .metric-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .charts-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 20px;
        }

        .chart-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 6px 12px rgba(0,0,0,0.1);
        }

        .chart-container {
            height: 300px;
            position: relative;
        }

        .quick-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .quick-action-btn {
            display: inline-flex;
            align-items: center;
            padding: 10px 15px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        .quick-action-btn:hover {
            background: #2980b9;
        }

        .quick-action-btn i {
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Admin Panel</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="employees.php"><i class="fas fa-users"></i> Employees List</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> Application List</a></li>
                <li><a href="departments.php"><i class="fas fa-building"></i> Department List</a></li>
                <li><a href="designations.php"><i class="fas fa-id-badge"></i> Designation List</a></li>
                <li><a href="leave-types.php"><i class="fas fa-calendar-alt"></i> Leave Type List</a></li>
                <li><a href="users.php"><i class="fas fa-user"></i> User List</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="header">
                <h1>Dashboard</h1>
                <div class="user-info">
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                </div>
            </div>

            <div class="dashboard-grid">
                <div class="metric-card">
                    <i class="fas fa-users metric-icon" style="color: #3498db;"></i>
                    <div class="metric-content">
                        <div class="metric-title">Total Employees</div>
                        <div class="metric-value"><?php echo $metrics['total_employees']['count']; ?></div>
                    </div>
                </div>

                <div class="metric-card">
                    <i class="fas fa-building metric-icon" style="color: #2ecc71;"></i>
                    <div class="metric-content">
                        <div class="metric-title">Total Departments</div>
                        <div class="metric-value"><?php echo $metrics['total_departments']['count']; ?></div>
                    </div>
                </div>

                <div class="metric-card">
                    <i class="fas fa-file-alt metric-icon" style="color: #e74c3c;"></i>
                    <div class="metric-content">
                        <div class="metric-title">Total Leave Applications</div>
                        <div class="metric-value"><?php echo $metrics['total_leave_applications']['count']; ?></div>
                    </div>
                </div>

                <div class="metric-card">
                    <i class="fas fa-hourglass-half metric-icon" style="color: #f39c12;"></i>
                    <div class="metric-content">
                        <div class="metric-title">Pending Applications</div>
                        <div class="metric-value"><?php echo $metrics['pending_applications']['count']; ?></div>
                    </div>
                </div>
            </div>



            <div class="charts-container">
                <div class="chart-card">
                    <h3>Leave Type Distribution</h3>
                    <div class="chart-container">
                        <canvas id="leaveTypeChart"></canvas>
                    </div>
                </div>
                <div class="chart-card">
                    <h3>Department Leave Statistics</h3>
                    <div class="chart-container">
                        <canvas id="departmentLeaveChart"></canvas>
                    </div>
                </div>
            </div>

            <div class="quick-actions">
                <a href="applications.php" class="quick-action-btn">
                    <i class="fas fa-file-alt"></i> View Leave Applications
                </a>
                <a href="add-employee.php" class="quick-action-btn">
                    <i class="fas fa-user-plus"></i> Add New Employee
                </a>
                <a href="reports.php" class="quick-action-btn">
                    <i class="fas fa-chart-bar"></i> Generate Reports
                </a>
            </div>
        </div>
    </div>

    <script>
        // Leave Type Distribution Chart
        const leaveTypeCtx = document.getElementById('leaveTypeChart').getContext('2d');
        new Chart(leaveTypeCtx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($leave_type_labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($leave_type_apps); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(153, 102, 255, 0.6)'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });

        // Department Leave Statistics Chart
        const departmentCtx = document.getElementById('departmentLeaveChart').getContext('2d');
        new Chart(departmentCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($dept_labels); ?>,
                datasets: [{
                    label: 'Total Leave Applications',
                    data: <?php echo json_encode($dept_apps); ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html> 