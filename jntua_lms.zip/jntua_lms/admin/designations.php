<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Process delete operation
if(isset($_GET["action"]) && $_GET["action"] == "delete" && isset($_GET["id"])) {
    $id = mysqli_real_escape_string($conn, $_GET["id"]);
    
    // Check if designation has associated employees
    $check_sql = "SELECT COUNT(*) as count FROM employees WHERE designation_id = ?";
    $stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $count = mysqli_fetch_assoc($result)['count'];

    if($count > 0) {
        $_SESSION['error'] = "Cannot delete designation. There are employees associated with it.";
    } else {
        $delete_sql = "DELETE FROM designations WHERE id = ?";
        if($stmt = mysqli_prepare($conn, $delete_sql)) {
            mysqli_stmt_bind_param($stmt, "i", $id);
            if(mysqli_stmt_execute($stmt)) {
                $_SESSION['success'] = "Designation deleted successfully.";
            } else {
                $_SESSION['error'] = "Error deleting designation.";
            }
        }
    }
    header("location: designations.php");
    exit();
}

// Process add/edit operations
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $rank = mysqli_real_escape_string($conn, $_POST['rank']);
    
    if(isset($_POST['id'])) {
        // Update operation
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        $sql = "UPDATE designations SET name = ?, description = ?, rank = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssii", $name, $description, $rank, $id);
    } else {
        // Insert operation
        $sql = "INSERT INTO designations (name, description, rank) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssi", $name, $description, $rank);
    }
    
    if(mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = isset($_POST['id']) ? "Designation updated successfully." : "Designation added successfully.";
    } else {
        $_SESSION['error'] = "Error " . (isset($_POST['id']) ? "updating" : "adding") . " designation.";
    }
    header("location: designations.php");
    exit();
}

// Fetch all designations with employee count
$sql = "SELECT d.*, COALESCE(d.rank, 999) as display_rank, COUNT(e.id) as employee_count 
        FROM designations d 
        LEFT JOIN employees e ON d.id = e.designation_id 
        GROUP BY d.id 
        ORDER BY display_rank, d.name";
try {
    $result = mysqli_query($conn, $sql);
    if (!$result) {
        throw new Exception(mysqli_error($conn));
    }
} catch (Exception $e) {
    $_SESSION['error'] = "Error fetching designations: " . $e->getMessage();
    $result = false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Designations - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Admin Panel</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="employees.php"><i class="fas fa-users"></i> Employees List</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> Application List</a></li>
                <li><a href="departments.php"><i class="fas fa-building"></i> Department List</a></li>
                <li><a href="designations.php" class="active"><i class="fas fa-id-badge"></i> Designation List</a></li>
                <li><a href="leave-types.php"><i class="fas fa-calendar-alt"></i> Leave Type List</a></li>
                <li><a href="users.php"><i class="fas fa-user"></i> User List</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Designations</h1>
                <div class="header-actions">
                    <button class="btn btn-primary" onclick="showAddModal()">
                        <i class="fas fa-plus"></i> Add Designation
                    </button>
                </div>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="content-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Designation Name</th>
                            <th>Description</th>
                            <th>Rank</th>
                            <th>Employees</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['description'] ?? ''); ?></td>
                                <td><?php echo ($row['rank'] !== null) ? htmlspecialchars($row['rank']) : 'Not Set'; ?></td>
                                <td><?php echo $row['employee_count']; ?></td>
                                <td><?php echo date('Y-m-d', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <button class="btn btn-primary btn-sm" onclick="showEditModal(<?php 
                                        echo htmlspecialchars(json_encode([
                                            'id' => $row['id'],
                                            'name' => $row['name'],
                                            'description' => $row['description'] ?? '',
                                            'rank' => $row['rank'] ?? 1
                                        ])); 
                                    ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php if($row['employee_count'] == 0): ?>
                                        <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo $row['id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add/Edit Designation Modal -->
    <div id="designationModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2 id="modalTitle">Add Designation</h2>
            <form id="designationForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" id="designation_id" name="id">
                <div class="form-group">
                    <label for="name">Designation Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="rank">Rank</label>
                    <input type="number" id="rank" name="rank" required min="1">
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <style>
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.4);
    }
    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 500px;
        border-radius: 8px;
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }
    .close:hover {
        color: black;
    }
    textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
        resize: vertical;
    }
    </style>

    <script>
    const modal = document.getElementById('designationModal');
    const span = document.getElementsByClassName('close')[0];

    function showAddModal() {
        document.getElementById('modalTitle').textContent = 'Add Designation';
        document.getElementById('designationForm').reset();
        document.getElementById('designation_id').value = '';
        modal.style.display = 'block';
    }

    function showEditModal(designation) {
        document.getElementById('modalTitle').textContent = 'Edit Designation';
        document.getElementById('designation_id').value = designation.id;
        document.getElementById('name').value = designation.name;
        document.getElementById('description').value = designation.description;
        document.getElementById('rank').value = designation.rank;
        modal.style.display = 'block';
    }

    function closeModal() {
        modal.style.display = 'none';
    }

    function confirmDelete(id) {
        if(confirm('Are you sure you want to delete this designation?')) {
            window.location.href = `designations.php?action=delete&id=${id}`;
        }
    }

    span.onclick = closeModal;
    window.onclick = function(event) {
        if (event.target == modal) {
            closeModal();
        }
    }
    </script>
</body>
</html> 