<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Check if id parameter exists
if(!isset($_GET["id"])) {
    header("location: employees.php");
    exit;
}

$id = mysqli_real_escape_string($conn, $_GET["id"]);

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate input
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $department_id = mysqli_real_escape_string($conn, $_POST['department_id']);
    $designation_id = mysqli_real_escape_string($conn, $_POST['designation_id']);
    $joining_date = mysqli_real_escape_string($conn, $_POST['joining_date']);

    // Start transaction
    mysqli_begin_transaction($conn);

    try {
        // Update employee details
        $update_sql = "UPDATE employees SET 
                      name = ?, 
                      email = ?, 
                      phone = ?, 
                      department_id = ?, 
                      designation_id = ?, 
                      joining_date = ? 
                      WHERE id = ?";
        
        $stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($stmt, "sssiisi", $name, $email, $phone, $department_id, $designation_id, $joining_date, $id);
        mysqli_stmt_execute($stmt);

        // Update password if provided
        if(!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
            
            $pass_sql = "UPDATE users SET password = ? WHERE id = ?";
            $stmt = mysqli_prepare($conn, $pass_sql);
            mysqli_stmt_bind_param($stmt, "si", $password, $user_id);
            mysqli_stmt_execute($stmt);
        }

        mysqli_commit($conn);
        $_SESSION['success'] = "Employee updated successfully.";
        header("location: employees.php");
        exit();
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = "Error updating employee. Please try again.";
    }
}

// Fetch employee data
$sql = "SELECT e.*, u.username, u.id as user_id 
        FROM employees e 
        JOIN users u ON e.user_id = u.id 
        WHERE e.id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($result) == 0) {
    header("location: employees.php");
    exit;
}

$employee = mysqli_fetch_assoc($result);

// Fetch departments and designations for dropdowns
$departments = mysqli_query($conn, "SELECT * FROM departments ORDER BY name");
$designations = mysqli_query($conn, "SELECT * FROM designations ORDER BY name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Admin Panel</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="employees.php" class="active"><i class="fas fa-users"></i> Employees List</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> Application List</a></li>
                <li><a href="departments.php"><i class="fas fa-building"></i> Department List</a></li>
                <li><a href="designations.php"><i class="fas fa-id-badge"></i> Designation List</a></li>
                <li><a href="leave-types.php"><i class="fas fa-calendar-alt"></i> Leave Type List</a></li>
                <li><a href="users.php"><i class="fas fa-user"></i> User List</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Edit Employee</h1>
            </div>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="content-wrapper">
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id=" . $id); ?>" class="form">
                    <input type="hidden" name="user_id" value="<?php echo $employee['user_id']; ?>">
                    
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($employee['name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($employee['email']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($employee['phone']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="department_id">Department</label>
                        <select id="department_id" name="department_id" required>
                            <option value="">Select Department</option>
                            <?php while($dept = mysqli_fetch_assoc($departments)): ?>
                                <option value="<?php echo $dept['id']; ?>" <?php echo ($dept['id'] == $employee['department_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($dept['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="designation_id">Designation</label>
                        <select id="designation_id" name="designation_id" required>
                            <option value="">Select Designation</option>
                            <?php while($desig = mysqli_fetch_assoc($designations)): ?>
                                <option value="<?php echo $desig['id']; ?>" <?php echo ($desig['id'] == $employee['designation_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($desig['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="joining_date">Joining Date</label>
                        <input type="date" id="joining_date" name="joining_date" value="<?php echo htmlspecialchars($employee['joining_date']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="username">Username (read-only)</label>
                        <input type="text" id="username" value="<?php echo htmlspecialchars($employee['username']); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label for="password">New Password (leave blank to keep current)</label>
                        <input type="password" id="password" name="password">
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Update Employee</button>
                        <a href="employees.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html> 