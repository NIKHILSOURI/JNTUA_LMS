<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Process delete operation
if(isset($_GET["action"]) && $_GET["action"] == "delete" && isset($_GET["id"])) {
    $id = mysqli_real_escape_string($conn, $_GET["id"]);
    $delete_sql = "DELETE FROM employees WHERE id = ?";
    if($stmt = mysqli_prepare($conn, $delete_sql)) {
        mysqli_stmt_bind_param($stmt, "i", $id);
        if(mysqli_stmt_execute($stmt)) {
            $_SESSION['success'] = "Employee deleted successfully.";
        } else {
            $_SESSION['error'] = "Error deleting employee.";
        }
        header("location: employees.php");
        exit();
    }
}

// Fetch all employees with department and designation names
$sql = "SELECT e.*, d.name as department_name, dg.name as designation_name 
        FROM employees e 
        JOIN departments d ON e.department_id = d.id 
        JOIN designations dg ON e.designation_id = dg.id 
        ORDER BY e.name";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employees List - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Admin Panel</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="employees.php" class="active"><i class="fas fa-users"></i> Employees List</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> Application List</a></li>
                <li><a href="departments.php"><i class="fas fa-building"></i> Department List</a></li>
                <li><a href="designations.php"><i class="fas fa-id-badge"></i> Designation List</a></li>
                <li><a href="leave-types.php"><i class="fas fa-calendar-alt"></i> Leave Type List</a></li>
                <li><a href="users.php"><i class="fas fa-user"></i> User List</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Employees List</h1>
                <div class="header-actions">
                    <a href="add-employee.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add New Employee
                    </a>
                </div>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="content-wrapper">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Department</th>
                                <th>Designation</th>
                                <th>Joining Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td><?php echo htmlspecialchars($row['department_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['designation_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['joining_date']); ?></td>
                                    <td class="actions">
                                        <a href="view-employee.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="edit-employee.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $row['id']; ?>)" class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
    function confirmDelete(id) {
        if(confirm('Are you sure you want to delete this employee?')) {
            window.location.href = 'employees.php?action=delete&id=' + id;
        }
    }
    </script>
</body>
</html> 