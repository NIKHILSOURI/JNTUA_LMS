<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Process delete operation
if(isset($_GET["action"]) && $_GET["action"] == "delete" && isset($_GET["id"])) {
    $id = mysqli_real_escape_string($conn, $_GET["id"]);
    
    // Check if leave type has associated applications
    $check_sql = "SELECT COUNT(*) as count FROM leave_applications WHERE leave_type_id = ?";
    $stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $count = mysqli_fetch_assoc($result)['count'];

    if($count > 0) {
        $_SESSION['error'] = "Cannot delete leave type. There are leave applications associated with it.";
    } else {
        // Start transaction
        mysqli_begin_transaction($conn);
        try {
            // Delete leave balances first
            $delete_balances = "DELETE FROM leave_balances WHERE leave_type_id = ?";
            $stmt = mysqli_prepare($conn, $delete_balances);
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);

            // Then delete the leave type
            $delete_sql = "DELETE FROM leave_types WHERE id = ?";
            $stmt = mysqli_prepare($conn, $delete_sql);
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);

            mysqli_commit($conn);
            $_SESSION['success'] = "Leave type deleted successfully.";
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $_SESSION['error'] = "Error deleting leave type.";
        }
    }
    header("location: leave-types.php");
    exit();
}

// Process add/edit operations
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $max_days = mysqli_real_escape_string($conn, $_POST['max_days']);
    $requires_attachment = isset($_POST['requires_attachment']) ? 1 : 0;
    
    if(isset($_POST['id'])) {
        // Update operation
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        $sql = "UPDATE leave_types SET name = ?, description = ?, max_days = ?, requires_attachment = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssiii", $name, $description, $max_days, $requires_attachment, $id);
    } else {
        // Insert operation
        $sql = "INSERT INTO leave_types (name, description, max_days, requires_attachment) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssii", $name, $description, $max_days, $requires_attachment);
    }
    
    if(mysqli_stmt_execute($stmt)) {
        if(!isset($_POST['id'])) {
            // For new leave types, initialize leave balances for all employees
            $leave_type_id = mysqli_insert_id($conn);
            $year = date('Y');
            
            $emp_sql = "SELECT id FROM employees";
            $emp_result = mysqli_query($conn, $emp_sql);
            
            while($emp = mysqli_fetch_assoc($emp_result)) {
                $balance_sql = "INSERT INTO leave_balances (employee_id, leave_type_id, year, total_leaves) VALUES (?, ?, ?, ?)";
                $stmt = mysqli_prepare($conn, $balance_sql);
                mysqli_stmt_bind_param($stmt, "iiii", $emp['id'], $leave_type_id, $year, $max_days);
                mysqli_stmt_execute($stmt);
            }
        }
        $_SESSION['success'] = isset($_POST['id']) ? "Leave type updated successfully." : "Leave type added successfully.";
    } else {
        $_SESSION['error'] = "Error " . (isset($_POST['id']) ? "updating" : "adding") . " leave type.";
    }
    header("location: leave-types.php");
    exit();
}

// Fetch all leave types with application count
$sql = "SELECT lt.*, COUNT(la.id) as application_count 
        FROM leave_types lt 
        LEFT JOIN leave_applications la ON lt.id = la.leave_type_id 
        GROUP BY lt.id 
        ORDER BY lt.name";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Types - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Admin Panel</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="employees.php"><i class="fas fa-users"></i> Employees List</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> Application List</a></li>
                <li><a href="departments.php"><i class="fas fa-building"></i> Department List</a></li>
                <li><a href="designations.php"><i class="fas fa-id-badge"></i> Designation List</a></li>
                <li><a href="leave-types.php" class="active"><i class="fas fa-calendar-alt"></i> Leave Type List</a></li>
                <li><a href="users.php"><i class="fas fa-user"></i> User List</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Leave Types</h1>
                <div class="header-actions">
                    <button class="btn btn-primary" onclick="showAddModal()">
                        <i class="fas fa-plus"></i> Add Leave Type
                    </button>
                </div>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="content-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Leave Type</th>
                            <th>Description</th>
                            <th>Max Days</th>
                            <th>Requires Attachment</th>
                            <th>Applications</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo !empty($row['description']) ? htmlspecialchars($row['description']) : '-'; ?></td>
                                <td><?php echo htmlspecialchars($row['max_days']); ?></td>
                                <td>
                                    <?php if($row['requires_attachment']): ?>
                                        <span class="badge badge-success">Yes</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">No</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $row['application_count']; ?></td>
                                <td><?php echo date('Y-m-d', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <button class="btn btn-primary btn-sm" onclick="showEditModal(<?php 
                                        echo htmlspecialchars(json_encode([
                                            'id' => $row['id'],
                                            'name' => $row['name'],
                                            'description' => $row['description'] ?? '',
                                            'max_days' => $row['max_days'],
                                            'requires_attachment' => $row['requires_attachment']
                                        ])); 
                                    ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php if($row['application_count'] == 0): ?>
                                        <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo $row['id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add/Edit Leave Type Modal -->
    <div id="leaveTypeModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2 id="modalTitle">Add Leave Type</h2>
            <form id="leaveTypeForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" id="leave_type_id" name="id">
                <div class="form-group">
                    <label for="name">Leave Type Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="max_days">Maximum Days Per Year</label>
                    <input type="number" id="max_days" name="max_days" required min="1">
                </div>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="requires_attachment" name="requires_attachment">
                        Requires Document Attachment
                    </label>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <style>
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.4);
    }
    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 500px;
        border-radius: 8px;
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }
    .close:hover {
        color: black;
    }
    textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
        resize: vertical;
    }
    .checkbox-label {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
    }
    .badge {
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
    }
    .badge-success {
        background-color: #28a745;
        color: white;
    }
    .badge-secondary {
        background-color: #6c757d;
        color: white;
    }
    </style>

    <script>
    const modal = document.getElementById('leaveTypeModal');
    const span = document.getElementsByClassName('close')[0];

    function showAddModal() {
        document.getElementById('modalTitle').textContent = 'Add Leave Type';
        document.getElementById('leaveTypeForm').reset();
        document.getElementById('leave_type_id').value = '';
        modal.style.display = 'block';
    }

    function showEditModal(leaveType) {
        document.getElementById('modalTitle').textContent = 'Edit Leave Type';
        document.getElementById('leave_type_id').value = leaveType.id;
        document.getElementById('name').value = leaveType.name;
        document.getElementById('description').value = leaveType.description;
        document.getElementById('max_days').value = leaveType.max_days;
        document.getElementById('requires_attachment').checked = leaveType.requires_attachment == 1;
        modal.style.display = 'block';
    }

    function closeModal() {
        modal.style.display = 'none';
    }

    function confirmDelete(id) {
        if(confirm('Are you sure you want to delete this leave type?')) {
            window.location.href = `leave-types.php?action=delete&id=${id}`;
        }
    }

    span.onclick = closeModal;
    window.onclick = function(event) {
        if (event.target == modal) {
            closeModal();
        }
    }
    </script>
</body>
</html> 