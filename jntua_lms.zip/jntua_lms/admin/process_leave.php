<?php
session_start();
require_once '../config/database.php';
require_once '../includes/notification_functions.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Validate input
if(!isset($_GET['id']) || !isset($_GET['action'])) {
    $_SESSION['error'] = "Invalid request parameters.";
    header("location: applications.php");
    exit;
}

// Sanitize inputs
$id = mysqli_real_escape_string($conn, $_GET['id']);
$action = mysqli_real_escape_string($conn, $_GET['action']);

// Determine status based on action
$status = ($action == 'approve') ? 'approved' : 'rejected';

// Get remarks if rejection
$remarks = '';
if ($status == 'rejected') {
    // For reject action, you might want to add a way to input remarks
    $remarks = isset($_GET['remarks']) ? mysqli_real_escape_string($conn, $_GET['remarks']) : 'Application rejected by admin';
}

// Process the leave application
if(process_leave_application($id, $status, $remarks)) {
    $_SESSION['success'] = "Leave application " . strtolower($status) . " successfully.";
} else {
    $_SESSION['error'] = "Error updating leave application status.";
}

// Redirect back to applications page
header("location: applications.php");
exit();
?> 