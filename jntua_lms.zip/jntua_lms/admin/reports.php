<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Default year for reports (current year)
$report_year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Fetch overall leave statistics
$leave_stats_query = "
    SELECT 
        lt.name AS leave_type,
        COUNT(la.id) AS total_applications,
        SUM(CASE WHEN la.status = 'approved' THEN 1 ELSE 0 END) AS approved_applications,
        SUM(CASE WHEN la.status = 'rejected' THEN 1 ELSE 0 END) AS rejected_applications,
        SUM(CASE WHEN la.status = 'pending' THEN 1 ELSE 0 END) AS pending_applications,
        SUM(la.days) AS total_days_applied,
        SUM(CASE WHEN la.status = 'approved' THEN la.days ELSE 0 END) AS total_days_approved
    FROM 
        leave_types lt
    LEFT JOIN 
        leave_applications la ON lt.id = la.leave_type_id AND YEAR(la.from_date) = ?
    GROUP BY 
        lt.id, lt.name
";
$stmt = mysqli_prepare($conn, $leave_stats_query);
mysqli_stmt_bind_param($stmt, "i", $report_year);
mysqli_stmt_execute($stmt);
$leave_stats_result = mysqli_stmt_get_result($stmt);

// Fetch department-wise leave statistics
$dept_stats_query = "
    SELECT 
        d.name AS department_name,
        COUNT(la.id) AS total_applications,
        SUM(CASE WHEN la.status = 'approved' THEN 1 ELSE 0 END) AS approved_applications,
        SUM(CASE WHEN la.status = 'rejected' THEN 1 ELSE 0 END) AS rejected_applications,
        SUM(la.days) AS total_days_applied
    FROM 
        departments d
    LEFT JOIN 
        employees e ON d.id = e.department_id
    LEFT JOIN 
        leave_applications la ON e.id = la.employee_id AND YEAR(la.from_date) = ?
    GROUP BY 
        d.id, d.name
    ORDER BY 
        total_applications DESC
";
$stmt = mysqli_prepare($conn, $dept_stats_query);
mysqli_stmt_bind_param($stmt, "i", $report_year);
mysqli_stmt_execute($stmt);
$dept_stats_result = mysqli_stmt_get_result($stmt);

// Fetch monthly leave trends
$monthly_trends_query = "
    SELECT 
        MONTH(from_date) AS month,
        COUNT(id) AS total_applications,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_applications,
        SUM(days) AS total_days
    FROM 
        leave_applications
    WHERE 
        YEAR(from_date) = ?
    GROUP BY 
        MONTH(from_date)
    ORDER BY 
        month
";
$stmt = mysqli_prepare($conn, $monthly_trends_query);
mysqli_stmt_bind_param($stmt, "i", $report_year);
mysqli_stmt_execute($stmt);
$monthly_trends_result = mysqli_stmt_get_result($stmt);

// Prepare monthly trends data for chart
$monthly_labels = [];
$monthly_total_apps = [];
$monthly_approved_apps = [];
$monthly_total_days = [];

while($row = mysqli_fetch_assoc($monthly_trends_result)) {
    $month_name = date('M', mktime(0, 0, 0, $row['month'], 1));
    $monthly_labels[] = $month_name;
    $monthly_total_apps[] = $row['total_applications'];
    $monthly_approved_apps[] = $row['approved_applications'];
    $monthly_total_days[] = $row['total_days'];
}

// Get available years for report
$years_query = "
    SELECT DISTINCT YEAR(from_date) AS report_year 
    FROM leave_applications 
    ORDER BY report_year DESC
";
$years_result = mysqli_query($conn, $years_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Reports - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .report-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .report-card {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        .year-selector {
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Admin Panel</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="employees.php"><i class="fas fa-users"></i> Employees List</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> Application List</a></li>
                <li><a href="departments.php"><i class="fas fa-building"></i> Department List</a></li>
                <li><a href="designations.php"><i class="fas fa-id-badge"></i> Designation List</a></li>
                <li><a href="leave-types.php"><i class="fas fa-calendar-alt"></i> Leave Type List</a></li>
                <li><a href="users.php"><i class="fas fa-user"></i> User List</a></li>
                <li><a href="reports.php" class="active"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Leave Management Reports</h1>
            </div>

            <div class="year-selector">
                <label for="report-year">Select Year:</label>
                <select id="report-year" onchange="changeReportYear()">
                    <?php while($year_row = mysqli_fetch_assoc($years_result)): ?>
                        <option value="<?php echo $year_row['report_year']; ?>" 
                                <?php echo $year_row['report_year'] == $report_year ? 'selected' : ''; ?>>
                            <?php echo $year_row['report_year']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="report-container">
                <!-- Leave Type Statistics -->
                <div class="report-card">
                    <h2>Leave Type Statistics (<?php echo $report_year; ?>)</h2>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Leave Type</th>
                                <th>Total Apps</th>
                                <th>Approved</th>
                                <th>Rejected</th>
                                <th>Pending</th>
                                <th>Days Applied</th>
                                <th>Days Approved</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($leave_stats_result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                                    <td><?php echo $row['total_applications'] ?: 0; ?></td>
                                    <td><?php echo $row['approved_applications'] ?: 0; ?></td>
                                    <td><?php echo $row['rejected_applications'] ?: 0; ?></td>
                                    <td><?php echo $row['pending_applications'] ?: 0; ?></td>
                                    <td><?php echo $row['total_days_applied'] ?: 0; ?></td>
                                    <td><?php echo $row['total_days_approved'] ?: 0; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Department-wise Leave Statistics -->
                <div class="report-card">
                    <h2>Department Leave Statistics (<?php echo $report_year; ?>)</h2>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Department</th>
                                <th>Total Apps</th>
                                <th>Approved</th>
                                <th>Rejected</th>
                                <th>Days Applied</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($dept_stats_result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['department_name']); ?></td>
                                    <td><?php echo $row['total_applications'] ?: 0; ?></td>
                                    <td><?php echo $row['approved_applications'] ?: 0; ?></td>
                                    <td><?php echo $row['rejected_applications'] ?: 0; ?></td>
                                    <td><?php echo $row['total_days_applied'] ?: 0; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Monthly Leave Trends Chart -->
                <div class="report-card" style="grid-column: 1 / -1;">
                    <h2>Monthly Leave Trends (<?php echo $report_year; ?>)</h2>
                    <div class="chart-container">
                        <canvas id="monthlyTrendsChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    function changeReportYear() {
        const selectedYear = document.getElementById('report-year').value;
        window.location.href = `reports.php?year=${selectedYear}`;
    }

    // Monthly Trends Chart
    const ctx = document.getElementById('monthlyTrendsChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($monthly_labels); ?>,
            datasets: [
                {
                    label: 'Total Applications',
                    data: <?php echo json_encode($monthly_total_apps); ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Approved Applications',
                    data: <?php echo json_encode($monthly_approved_apps); ?>,
                    backgroundColor: 'rgba(75, 192, 192, 0.5)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    </script>
</body>
</html> 