<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Process delete operation
if(isset($_GET["action"]) && $_GET["action"] == "delete" && isset($_GET["id"])) {
    $id = mysqli_real_escape_string($conn, $_GET["id"]);
    
    // Prevent admin from deleting their own account
    if(isset($_SESSION['id']) && $id == $_SESSION['id']) {
        $_SESSION['error'] = "You cannot delete your own account.";
        header("location: users.php");
        exit();
    }

    // Start transaction
    mysqli_begin_transaction($conn);
    try {
        // Delete employee record if exists
        $delete_emp = "DELETE FROM employees WHERE user_id = ?";
        $stmt = mysqli_prepare($conn, $delete_emp);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);

        // Delete user
        $delete_sql = "DELETE FROM users WHERE id = ?";
        $stmt = mysqli_prepare($conn, $delete_sql);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);

        mysqli_commit($conn);
        $_SESSION['success'] = "User deleted successfully.";
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = "Error deleting user.";
    }
    header("location: users.php");
    exit();
}

// Process password reset
if(isset($_GET["action"]) && $_GET["action"] == "reset" && isset($_GET["id"])) {
    $id = mysqli_real_escape_string($conn, $_GET["id"]);
    $default_password = password_hash("jntua123", PASSWORD_DEFAULT);
    
    $sql = "UPDATE users SET password = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $default_password, $id);
    
    if(mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Password reset successfully. Default password: jntua123";
    } else {
        $_SESSION['error'] = "Error resetting password.";
    }
    header("location: users.php");
    exit();
}

// Process status toggle
if(isset($_GET["action"]) && $_GET["action"] == "toggle" && isset($_GET["id"])) {
    $id = mysqli_real_escape_string($conn, $_GET["id"]);
    
    // Prevent admin from deactivating their own account
    if(isset($_SESSION['id']) && $id == $_SESSION['id']) {
        $_SESSION['error'] = "You cannot deactivate your own account.";
        header("location: users.php");
        exit();
    }

    $sql = "UPDATE users SET is_active = NOT is_active WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    
    if(mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "User status updated successfully.";
    } else {
        $_SESSION['error'] = "Error updating user status.";
    }
    header("location: users.php");
    exit();
}

// Fetch all users with employee details if available
$sql = "SELECT u.*, e.name as employee_name, e.email as employee_email 
        FROM users u 
        LEFT JOIN employees e ON u.id = e.user_id 
        ORDER BY u.username";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Admin Panel</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="employees.php"><i class="fas fa-users"></i> Employees List</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> Application List</a></li>
                <li><a href="departments.php"><i class="fas fa-building"></i> Department List</a></li>
                <li><a href="designations.php"><i class="fas fa-id-badge"></i> Designation List</a></li>
                <li><a href="leave-types.php"><i class="fas fa-calendar-alt"></i> Leave Type List</a></li>
                <li><a href="users.php" class="active"><i class="fas fa-user"></i> User List</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Users</h1>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="content-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Employee Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['username']); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $row['role'] == 'admin' ? 'primary' : 'info'; ?>">
                                        <?php echo ucfirst(htmlspecialchars($row['role'])); ?>
                                    </span>
                                </td>
                                <td><?php echo $row['employee_name'] ? htmlspecialchars($row['employee_name']) : '-'; ?></td>
                                <td><?php echo $row['employee_email'] ? htmlspecialchars($row['employee_email']) : '-'; ?></td>
                                <td>
                                    <span class="badge badge-<?php echo isset($row['is_active']) && $row['is_active'] ? 'success' : 'danger'; ?>">
                                        <?php echo isset($row['is_active']) && $row['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td><?php echo isset($row['last_login']) && $row['last_login'] ? date('Y-m-d H:i', strtotime($row['last_login'])) : 'Never'; ?></td>
                                <td><?php echo date('Y-m-d', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <?php if(isset($_SESSION['id']) && $row['id'] != $_SESSION['id']): ?>
                                        <button class="btn btn-warning btn-sm" onclick="confirmReset(<?php echo $row['id']; ?>)" title="Reset Password">
                                            <i class="fas fa-key"></i>
                                        </button>
                                        <button class="btn <?php echo isset($row['is_active']) && $row['is_active'] ? 'btn-danger' : 'btn-success'; ?> btn-sm" 
                                                onclick="confirmToggle(<?php echo $row['id']; ?>, <?php echo isset($row['is_active']) && $row['is_active'] ? 'true' : 'false'; ?>)" 
                                                title="<?php echo isset($row['is_active']) && $row['is_active'] ? 'Deactivate' : 'Activate'; ?> User">
                                            <i class="fas <?php echo isset($row['is_active']) && $row['is_active'] ? 'fa-user-slash' : 'fa-user-check'; ?>"></i>
                                        </button>
                                        <?php if($row['role'] != 'admin'): ?>
                                            <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo $row['id']; ?>)" title="Delete User">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <style>
    .badge {
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
    }
    .badge-success {
        background-color: #28a745;
        color: white;
    }
    .badge-danger {
        background-color: #dc3545;
        color: white;
    }
    .badge-primary {
        background-color: #007bff;
        color: white;
    }
    .badge-info {
        background-color: #17a2b8;
        color: white;
    }
    </style>

    <script>
    function confirmReset(id) {
        if(confirm('Are you sure you want to reset this user\'s password to default?')) {
            window.location.href = `users.php?action=reset&id=${id}`;
        }
    }

    function confirmToggle(id, currentStatus) {
        const action = currentStatus ? 'deactivate' : 'activate';
        if(confirm(`Are you sure you want to ${action} this user?`)) {
            window.location.href = `users.php?action=toggle&id=${id}`;
        }
    }

    function confirmDelete(id) {
        if(confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
            window.location.href = `users.php?action=delete&id=${id}`;
        }
    }
    </script>
</body>
</html> 