<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "admin"){
    header("location: ../index.php");
    exit;
}

// Check if id parameter exists
if(!isset($_GET["id"])) {
    header("location: employees.php");
    exit;
}

$id = mysqli_real_escape_string($conn, $_GET["id"]);

// Fetch employee data with department and designation
$sql = "SELECT e.*, d.name as department_name, dg.name as designation_name, u.username 
        FROM employees e 
        JOIN departments d ON e.department_id = d.id 
        JOIN designations dg ON e.designation_id = dg.id 
        JOIN users u ON e.user_id = u.id 
        WHERE e.id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($result) == 0) {
    header("location: employees.php");
    exit;
}

$employee = mysqli_fetch_assoc($result);

// Fetch leave balances with default values
$balance_sql = "
    SELECT 
        lt.id as leave_type_id,
        lt.name as leave_type, 
        lt.max_days as total_leaves,
        COALESCE(lb.leaves_taken, 0) as leaves_taken
    FROM 
        leave_types lt
    LEFT JOIN 
        leave_balances lb ON lb.leave_type_id = lt.id 
        AND lb.employee_id = ? 
        AND lb.year = YEAR(CURRENT_DATE)
    ORDER BY 
        lt.name
";
$stmt = mysqli_prepare($conn, $balance_sql);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$balances = mysqli_stmt_get_result($stmt);

// Fetch recent leave applications
$applications_sql = "SELECT la.*, lt.name as leave_type 
                    FROM leave_applications la 
                    JOIN leave_types lt ON la.leave_type_id = lt.id 
                    WHERE la.employee_id = ? 
                    ORDER BY la.created_at DESC LIMIT 5";
$stmt = mysqli_prepare($conn, $applications_sql);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$applications = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Employee - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Admin Panel</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="employees.php" class="active"><i class="fas fa-users"></i> Employees List</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> Application List</a></li>
                <li><a href="departments.php"><i class="fas fa-building"></i> Department List</a></li>
                <li><a href="designations.php"><i class="fas fa-id-badge"></i> Designation List</a></li>
                <li><a href="leave-types.php"><i class="fas fa-calendar-alt"></i> Leave Type List</a></li>
                <li><a href="users.php"><i class="fas fa-user"></i> User List</a></li>
                <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Employee Details</h1>
                <div class="header-actions">
                    <a href="edit-employee.php?id=<?php echo $id; ?>" class="btn btn-primary">
                        <i class="fas fa-edit"></i> Edit Employee
                    </a>
                    <a href="employees.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to List
                    </a>
                </div>
            </div>

            <div class="content-wrapper">
                <div class="employee-details">
                    <div class="detail-section">
                        <h2>Personal Information</h2>
                        <div class="detail-grid">
                            <div class="detail-item">
                                <label>Full Name:</label>
                                <span><?php echo htmlspecialchars($employee['name']); ?></span>
                            </div>
                            <div class="detail-item">
                                <label>Email:</label>
                                <span><?php echo htmlspecialchars($employee['email']); ?></span>
                            </div>
                            <div class="detail-item">
                                <label>Phone:</label>
                                <span><?php echo htmlspecialchars($employee['phone']); ?></span>
                            </div>
                            <div class="detail-item">
                                <label>Username:</label>
                                <span><?php echo htmlspecialchars($employee['username']); ?></span>
                            </div>
                            <div class="detail-item">
                                <label>Department:</label>
                                <span><?php echo htmlspecialchars($employee['department_name']); ?></span>
                            </div>
                            <div class="detail-item">
                                <label>Designation:</label>
                                <span><?php echo htmlspecialchars($employee['designation_name']); ?></span>
                            </div>
                            <div class="detail-item">
                                <label>Joining Date:</label>
                                <span><?php echo htmlspecialchars($employee['joining_date']); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="detail-section">
                        <h2>Leave Balances (<?php echo date('Y'); ?>)</h2>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Leave Type</th>
                                    <th>Total Leaves</th>
                                    <th>Leaves Taken</th>
                                    <th>Available Leaves</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($balance = mysqli_fetch_assoc($balances)): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($balance['leave_type']); ?></td>
                                        <td><?php echo intval($balance['total_leaves']); ?></td>
                                        <td><?php echo intval($balance['leaves_taken']); ?></td>
                                        <td><?php echo intval($balance['total_leaves'] - $balance['leaves_taken']); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="detail-section">
                        <h2>Recent Leave Applications</h2>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Leave Type</th>
                                    <th>From Date</th>
                                    <th>To Date</th>
                                    <th>Days</th>
                                    <th>Status</th>
                                    <th>Applied On</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($app = mysqli_fetch_assoc($applications)): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($app['leave_type']); ?></td>
                                        <td><?php echo htmlspecialchars($app['from_date']); ?></td>
                                        <td><?php echo htmlspecialchars($app['to_date']); ?></td>
                                        <td><?php echo htmlspecialchars($app['days']); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo strtolower($app['status']); ?>">
                                                <?php echo ucfirst(htmlspecialchars($app['status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('Y-m-d', strtotime($app['created_at'])); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 