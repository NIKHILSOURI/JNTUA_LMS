<?php
// Ensure only one session_start()
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Enable detailed error logging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/login_debug.log');

// Function to log debug information
function login_debug_log($message) {
    error_log('[' . date('Y-m-d H:i:s') . '] ' . $message);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = $_POST['password'];
    $role = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING);

    // Log input details
    login_debug_log("Login attempt - Username: $username, Role: $role");

    // Validate inputs
    if (empty($username) || empty($password) || empty($role)) {
        login_debug_log("Validation failed - Empty fields");
        $_SESSION['error'] = "Please fill in all fields.";
        header("location: ../index.php");
        exit();
    }
    
    // Prepare SQL to prevent SQL injection
    $sql = "SELECT u.id, u.username, u.password, u.role, u.is_active, e.id as employee_id 
            FROM users u
            LEFT JOIN employees e ON u.id = e.user_id
            WHERE u.username = ? AND u.role = ?";
    
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "ss", $username, $role);
        
        if (mysqli_stmt_execute($stmt)) {
            $result = mysqli_stmt_get_result($stmt);
            
            if (mysqli_num_rows($result) == 1) {
                $user = mysqli_fetch_assoc($result);
                
                login_debug_log("User found - ID: {$user['id']}, Username: {$user['username']}, Role: {$user['role']}, Active: {$user['is_active']}, Employee ID: {$user['employee_id']}");
                
                // Verify password
                if (password_verify($password, $user['password'])) {
                    // Check if user is active
                    if ($user['is_active'] != 1) {
                        login_debug_log("Login failed - Account not active");
                        $_SESSION['error'] = "Your account is not active.";
                        header("location: ../index.php");
                        exit();
                    }
                    
                    // Regenerate session ID for security
                    session_regenerate_id(true);
                    
                    // Store user data in session
                    $_SESSION["loggedin"] = true;
                    $_SESSION["id"] = $user['id'];
                    $_SESSION["username"] = $user['username'];
                    $_SESSION["role"] = $user['role'];
                    $_SESSION["user_id"] = $user['id'];  // Add this line
                    
                    // For faculty, ensure employee record exists
                    if ($user['role'] == "faculty") {
                        if (empty($user['employee_id'])) {
                            login_debug_log("Login failed - No employee record found");
                            $_SESSION['error'] = "No employee record found. Contact administrator.";
                            header("location: ../index.php");
                            exit();
                        }
                        
                        login_debug_log("Faculty login successful - Redirecting to dashboard");
                        header("location: ../faculty/dashboard.php");
                    } elseif ($user['role'] == "admin") {
                        login_debug_log("Admin login successful - Redirecting to dashboard");
                        header("location: ../admin/dashboard.php");
                    } else {
                        login_debug_log("Login failed - Invalid user role");
                        $_SESSION['error'] = "Invalid user role.";
                        header("location: ../index.php");
                    }
                    exit();
                } else {
                    login_debug_log("Login failed - Invalid password");
                    $_SESSION['error'] = "Invalid username or password.";
                    header("location: ../index.php");
                    exit();
                }
            } else {
                login_debug_log("Login failed - User not found");
                $_SESSION['error'] = "Invalid username or role.";
                header("location: ../index.php");
                exit();
            }
        } else {
            login_debug_log("Database query error: " . mysqli_error($conn));
            $_SESSION['error'] = "A system error occurred. Please try again later.";
            header("location: ../index.php");
            exit();
        }
    }
    
    mysqli_close($conn);
} else {
    header("location: ../index.php");
    exit();
}
?> 