-- Add rank and description columns to designations table
ALTER TABLE designations
ADD COLUMN rank INT DEFAULT 1 AFTER name,
ADD COLUMN description TEXT AFTER rank;

-- Update existing designations with default ranks
UPDATE designations SET rank = 1 WHERE name = 'Professor';
UPDATE designations SET rank = 2 WHERE name = 'Associate Professor';
UPDATE designations SET rank = 3 WHERE name = 'Assistant Professor';
UPDATE designations SET rank = 1 WHERE name = 'Head of Department';
UPDATE designations SET rank = 4 WHERE name = 'Assistant Professor(Adhoc)';
UPDATE designations SET rank = 5 WHERE name = 'Staff'; 