-- Add application_id column to notifications table
ALTER TABLE notifications
ADD COLUMN application_id INT,
ADD FOREIGN KEY (application_id) REFERENCES leave_applications(id); 