-- JNTUA Leave Management System Sample Data Script
-- Version: 1.0
-- Last Updated: 2024-02-15

USE jntua_lms;

-- Disable foreign key checks
SET FOREIGN_KEY_CHECKS = 0;

-- Insert default admin user (password: Admin@2024)
INSERT INTO users (username, password, role, is_active) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1);

-- Insert comprehensive departments
INSERT INTO departments (name, code, description, is_active) VALUES 
('Computer Science and Engineering', 'CSE', 'Department of Computer Science and Engineering', 1),
('Electronics and Communication Engineering', 'ECE', 'Department of Electronics and Communication Engineering', 1),
('Mechanical Engineering', 'MECH', 'Department of Mechanical Engineering', 1),
('Civil Engineering', 'CIVIL', 'Department of Civil Engineering', 1),
('Electrical and Electronics Engineering', 'EEE', 'Department of Electrical and Electronics Engineering', 1);

-- Insert comprehensive designations
INSERT INTO designations (name, description, is_active) VALUES 
('Professor', 'Senior academic position with extensive research and teaching experience', 1),
('Associate Professor', 'Mid-level academic position with significant teaching and research contributions', 1),
('Assistant Professor', 'Junior academic position focused on teaching and research development', 1),
('Head of Department', 'Administrative and academic leadership role for a department', 1),
('Adjunct Faculty', 'Part-time or visiting faculty member', 1);

-- Insert comprehensive leave types
INSERT INTO leave_types (name, description, max_days, requires_attachment, is_active) VALUES 
('Casual Leave', 'Short-term leave for personal or urgent matters', 12, 0, 1),
('Medical Leave', 'Leave for medical treatment, consultation, or recovery', 15, 1, 1),
('Vacation Leave', 'Extended leave for rest, relaxation, and personal travel', 30, 0, 1),
('Academic Leave', 'Leave for attending conferences, workshops, or academic pursuits', 10, 1, 1),
('Maternity Leave', 'Extended leave for new mothers to care for their newborn', 180, 1, 1);

-- Insert faculty users with hashed passwords (password: Test@123)
INSERT INTO users (username, password, role, is_active) VALUES 
('fac1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', 1),
('fac2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', 1),
('fac3', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', 1),
('fac4', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', 1),
('fac5', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', 1);

-- Insert employee records
INSERT INTO employees (user_id, employee_id, name, email, phone, department_id, designation_id, joining_date, is_active) VALUES 
(2, 'JNTUA-CSE-001', 'Dr. Rajesh Kumar', 'rajesh.kumar@jntua.ac.in', '9876543210', 1, 1, '2010-06-15', 1),
(3, 'JNTUA-ECE-002', 'Dr. Priya Sharma', 'priya.sharma@jntua.ac.in', '9988776655', 2, 2, '2012-08-20', 1),
(4, 'JNTUA-MECH-003', 'Prof. Sanjay Gupta', 'sanjay.gupta@jntua.ac.in', '7766554433', 3, 3, '2015-03-10', 1),
(5, 'JNTUA-CIVIL-004', 'Dr. Anita Patel', 'anita.patel@jntua.ac.in', '8877665544', 4, 4, '2011-11-05', 1),
(6, 'JNTUA-EEE-005', 'Prof. Vikram Singh', 'vikram.singh@jntua.ac.in', '9900112233', 5, 5, '2014-07-25', 1);

-- Initialize leave balances for the current year
INSERT INTO leave_balances (employee_id, leave_type_id, year, total_leaves, leaves_taken) VALUES 
(1, 1, YEAR(CURRENT_DATE), 12, 0),
(1, 2, YEAR(CURRENT_DATE), 15, 0),
(1, 3, YEAR(CURRENT_DATE), 30, 0),
(1, 4, YEAR(CURRENT_DATE), 10, 0),
(1, 5, YEAR(CURRENT_DATE), 180, 0),
(2, 1, YEAR(CURRENT_DATE), 12, 0),
(2, 2, YEAR(CURRENT_DATE), 15, 0),
(2, 3, YEAR(CURRENT_DATE), 30, 0),
(2, 4, YEAR(CURRENT_DATE), 10, 0),
(2, 5, YEAR(CURRENT_DATE), 180, 0),
(3, 1, YEAR(CURRENT_DATE), 12, 0),
(3, 2, YEAR(CURRENT_DATE), 15, 0),
(3, 3, YEAR(CURRENT_DATE), 30, 0),
(3, 4, YEAR(CURRENT_DATE), 10, 0),
(3, 5, YEAR(CURRENT_DATE), 180, 0),
(4, 1, YEAR(CURRENT_DATE), 12, 0),
(4, 2, YEAR(CURRENT_DATE), 15, 0),
(4, 3, YEAR(CURRENT_DATE), 30, 0),
(4, 4, YEAR(CURRENT_DATE), 10, 0),
(4, 5, YEAR(CURRENT_DATE), 180, 0),
(5, 1, YEAR(CURRENT_DATE), 12, 0),
(5, 2, YEAR(CURRENT_DATE), 15, 0),
(5, 3, YEAR(CURRENT_DATE), 30, 0),
(5, 4, YEAR(CURRENT_DATE), 10, 0),
(5, 5, YEAR(CURRENT_DATE), 180, 0);

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- Commit the transaction
COMMIT; 