-- Sample data for JNTUA Leave Management System
USE jntua_lms;

-- Clear existing data to avoid duplicates
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE notifications;
TRUNCATE TABLE leave_applications;
TRUNCATE TABLE leave_balances;
TRUNCATE TABLE employees;
TRUNCATE TABLE users;
TRUNCATE TABLE leave_types;
TRUNCATE TABLE designations;
TRUNCATE TABLE departments;
SET FOREIGN_KEY_CHECKS = 1;

-- Departments
INSERT INTO departments (name, code, created_at) VALUES
('Computer Science and Engineering', 'CSE', NOW()),
('Electronics and Communication Engineering', 'ECE', NOW()),
('Mechanical Engineering', 'ME', NOW()),
('Civil Engineering', 'CE', NOW()),
('Chemical Engineering', 'CHE', NOW()),
('Electrical and Electronics Engineering', 'EEE', NOW());

-- Designations
INSERT INTO designations (name, description, rank, created_at) VALUES
('Professor', 'Senior academic position responsible for teaching and research', 1, NOW()),
('Associate Professor', 'Mid-level academic position with significant teaching and research experience', 2, NOW()),
('Assistant Professor', 'Junior academic position focused on teaching and developing research skills', 3, NOW()),
('Assistant Professor(Adhoc)', 'Temporary academic position with limited responsibilities', 4, NOW()),
('Head of Department', 'Administrative role leading a department\'s academic and administrative functions', 5, NOW()),
('Lab Assistant', 'Technical support role assisting in laboratory operations and maintenance', 6, NOW());

-- Leave Types
INSERT INTO leave_types (name, description, max_days, requires_attachment, created_at) VALUES
('Casual Leave', 'Short-term leave for personal or urgent matters', 12, 0, NOW()),
('Medical Leave', 'Leave for medical treatment, consultation, or recovery', 15, 1, NOW()),
('Vacation Leave', 'Extended leave for rest, relaxation, and personal travel', 30, 0, NOW()),
('Academic Leave', 'Leave for attending conferences, workshops, or academic pursuits', 10, 1, NOW()),
('Maternity Leave', 'Extended leave for new mothers to care for their newborn', 180, 1, NOW());

-- Users (password: password for all users)
INSERT INTO users (username, password, role, is_active, created_at) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', TRUE, NOW()),
('fac1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', TRUE, NOW()),
('fac2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', TRUE, NOW()),
('fac3', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', TRUE, NOW()),
('fac4', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', TRUE, NOW()),
('fac5', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', TRUE, NOW());

-- Employees
INSERT INTO employees (user_id, employee_id, name, email, phone, department_id, designation_id, joining_date, created_at) VALUES
(2, 'CSE001', 'Dr. Rajesh Kumar', 'rajesh.kumar@jntua.ac.in', '9876543210', 1, 1, '2020-06-15', NOW()),
(3, 'ECE001', 'Dr. Priya Sharma', 'priya.sharma@jntua.ac.in', '9876543211', 2, 2, '2019-08-01', NOW()),
(4, 'ME001', 'Dr. Suresh Reddy', 'suresh.reddy@jntua.ac.in', '9876543212', 3, 3, '2021-01-10', NOW()),
(5, 'CE001', 'Dr. Lakshmi Devi', 'lakshmi.devi@jntua.ac.in', '9876543213', 4, 4, '2018-11-20', NOW()),
(6, 'CHE001', 'Dr. Venkat Rao', 'venkat.rao@jntua.ac.in', '9876543214', 5, 2, '2020-03-05', NOW());

-- Leave Balances for 2024
INSERT INTO leave_balances (employee_id, leave_type_id, max_days, leaves_taken, year, created_at) VALUES
-- Rajesh Kumar's balances
(1, 1, 12, 4, 2024, NOW()),  -- Casual Leave
(1, 2, 15, 0, 2024, NOW()),  -- Medical Leave
(1, 3, 30, 10, 2024, NOW()), -- Vacation Leave
(1, 4, 10, 2, 2024, NOW()),  -- Academic Leave

-- Priya Sharma's balances
(2, 1, 12, 6, 2024, NOW()),
(2, 2, 15, 5, 2024, NOW()),
(2, 3, 30, 15, 2024, NOW()),
(2, 4, 10, 4, 2024, NOW()),

-- Suresh Reddy's balances
(3, 1, 12, 2, 2024, NOW()),
(3, 2, 15, 0, 2024, NOW()),
(3, 3, 30, 5, 2024, NOW()),
(3, 4, 10, 1, 2024, NOW()),

-- Lakshmi Devi's balances
(4, 1, 12, 8, 2024, NOW()),
(4, 2, 15, 7, 2024, NOW()),
(4, 3, 30, 20, 2024, NOW()),
(4, 4, 10, 3, 2024, NOW()),

-- Venkat Rao's balances
(5, 1, 12, 3, 2024, NOW()),
(5, 2, 15, 2, 2024, NOW()),
(5, 3, 30, 8, 2024, NOW()),
(5, 4, 10, 0, 2024, NOW());

-- Leave Applications
INSERT INTO leave_applications (employee_id, leave_type_id, from_date, to_date, days, reason, status, remarks, created_at) VALUES
-- Rajesh Kumar's applications
(1, 1, '2024-02-01', '2024-02-02', 2, 'Family function', 'approved', 'Approved as requested', '2024-01-25 10:00:00'),
(1, 3, '2024-04-15', '2024-04-25', 10, 'Summer vacation', 'approved', NULL, '2024-03-20 14:30:00'),
(1, 4, '2024-06-10', '2024-06-11', 2, 'Conference attendance at IIT Delhi', 'pending', NULL, '2024-05-25 09:15:00'),

-- Priya Sharma's applications
(2, 1, '2024-02-15', '2024-02-16', 2, 'Personal work', 'approved', NULL, '2024-02-10 11:20:00'),
(2, 2, '2024-03-10', '2024-03-14', 5, 'Medical treatment', 'approved', 'Get well soon', '2024-03-05 16:45:00'),
(2, 3, '2024-05-01', '2024-05-15', 15, 'Family vacation', 'rejected', 'Department event scheduled', '2024-04-15 13:30:00'),

-- Suresh Reddy's applications
(3, 1, '2024-02-20', '2024-02-21', 2, 'Personal emergency', 'approved', NULL, '2024-02-19 08:00:00'),
(3, 3, '2024-07-01', '2024-07-05', 5, 'Family trip', 'pending', NULL, '2024-06-15 10:30:00'),

-- Lakshmi Devi's applications
(4, 1, '2024-03-05', '2024-03-06', 2, 'Personal work', 'approved', NULL, '2024-03-01 09:45:00'),
(4, 2, '2024-04-10', '2024-04-16', 7, 'Hospital admission', 'approved', 'Approved based on medical certificate', '2024-04-09 11:20:00'),
(4, 3, '2024-06-01', '2024-06-20', 20, 'Summer vacation', 'approved', NULL, '2024-05-15 14:00:00'),

-- Venkat Rao's applications
(5, 1, '2024-02-25', '2024-02-27', 3, 'Family function', 'approved', NULL, '2024-02-20 15:30:00'),
(5, 2, '2024-05-05', '2024-05-06', 2, 'Medical checkup', 'approved', NULL, '2024-05-01 10:15:00'),
(5, 3, '2024-07-10', '2024-07-17', 8, 'Family vacation', 'pending', NULL, '2024-06-25 13:45:00');

-- Notifications
INSERT INTO notifications (employee_id, message, type, leave_application_id, is_read, created_at) VALUES
-- Rajesh Kumar's notifications
(1, 'Your Casual Leave application has been approved', 'status_update', 1, 1, '2024-01-26 09:00:00'),
(1, 'Your Vacation Leave application has been approved', 'status_update', 2, 1, '2024-03-21 10:30:00'),
(1, 'Low balance alert: You have 2 Casual Leave days remaining', 'balance_alert', NULL, 0, '2024-02-03 08:00:00'),

-- Priya Sharma's notifications
(2, 'Your Casual Leave application has been approved', 'status_update', 4, 1, '2024-02-11 14:20:00'),
(2, 'Your Medical Leave application has been approved', 'status_update', 5, 1, '2024-03-06 09:15:00'),
(2, 'Your Vacation Leave application has been rejected. Remarks: Department event scheduled', 'status_update', 6, 0, '2024-04-16 11:30:00'),

-- Suresh Reddy's notifications
(3, 'Your Casual Leave application has been approved', 'status_update', 7, 1, '2024-02-19 10:00:00'),
(3, 'Reminder: Your Casual Leave starts tomorrow', 'reminder', 7, 1, '2024-02-19 16:00:00'),

-- Lakshmi Devi's notifications
(4, 'Your Casual Leave application has been approved', 'status_update', 9, 1, '2024-03-02 08:30:00'),
(4, 'Your Medical Leave application has been approved', 'status_update', 10, 1, '2024-04-09 14:45:00'),
(4, 'Your Vacation Leave application has been approved', 'status_update', 11, 0, '2024-05-16 09:30:00'),
(4, 'Low balance alert: You have 2 Vacation Leave days remaining', 'balance_alert', NULL, 0, '2024-06-21 10:00:00'),

-- Venkat Rao's notifications
(5, 'Your Casual Leave application has been approved', 'status_update', 12, 1, '2024-02-21 08:15:00'),
(5, 'Your Medical Leave application has been approved', 'status_update', 13, 1, '2024-05-02 11:30:00'),
(5, 'Reminder: Your Medical Leave starts tomorrow', 'reminder', 13, 0, '2024-05-04 16:00:00'); 