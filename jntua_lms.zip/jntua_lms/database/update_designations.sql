-- First ensure the columns exist
ALTER TABLE designations
ADD COLUMN IF NOT EXISTS rank INT DEFAULT 1 AFTER name,
ADD COLUMN IF NOT EXISTS description TEXT AFTER rank;

-- Update existing designations with proper ranks and descriptions
UPDATE designations 
SET rank = 1,
    description = 'Senior academic position with extensive research and teaching experience'
WHERE name = 'Professor';

UPDATE designations 
SET rank = 2,
    description = 'Mid-level academic position with significant teaching and research contributions'
WHERE name = 'Associate Professor';

UPDATE designations 
SET rank = 3,
    description = 'Junior academic position focused on teaching and research development'
WHERE name = 'Assistant Professor';

UPDATE designations 
SET rank = 1,
    description = 'Administrative and academic leadership role for a department'
WHERE name = 'Head of Department';

UPDATE designations 
SET rank = 4,
    description = 'Part-time or visiting faculty member'
WHERE name = 'Adjunct Faculty';

-- Set default rank for any unranked designations
UPDATE designations 
SET rank = 999 
WHERE rank IS NULL; 