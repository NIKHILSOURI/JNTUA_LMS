<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is faculty
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "faculty"){
    header("location: ../index.php");
    exit;
}

// Get employee ID
$employee_sql = "SELECT id FROM employees WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $employee_sql);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$employee_result = mysqli_stmt_get_result($stmt);
$employee = mysqli_fetch_assoc($employee_result);

// Add error handling for employee details
if (!$employee) {
    // Redirect or show an error message if no employee found
    $_SESSION['error'] = "Employee details not found.";
    header("location: ../index.php");
    exit;
}

// Ensure employee ID exists with a default value
$employee = array_merge([
    'id' => 0
], $employee ?? []);

// Get filter values
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$leave_type_filter = isset($_GET['leave_type']) ? intval($_GET['leave_type']) : '';
$year_filter = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Build query conditions
$conditions = ["la.employee_id = ?", "YEAR(la.from_date) = ?"];
$params = [$employee['id'], $year_filter];
$types = "ii";

if($status_filter) {
    $conditions[] = "la.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

if($leave_type_filter) {
    $conditions[] = "la.leave_type_id = ?";
    $params[] = $leave_type_filter;
    $types .= "i";
}

$where_clause = implode(" AND ", $conditions);

// Fetch all leave applications
$sql = "SELECT la.*, lt.name as leave_type, lt.requires_attachment
        FROM leave_applications la 
        JOIN leave_types lt ON la.leave_type_id = lt.id
        WHERE $where_clause
        ORDER BY la.created_at DESC";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Fetch leave types for filter
$leave_types = mysqli_query($conn, "SELECT * FROM leave_types ORDER BY name");

// Get unread notifications count
$unread_sql = "SELECT COUNT(*) as count FROM notifications WHERE employee_id = ? AND is_read = 0";
$stmt = mysqli_prepare($conn, $unread_sql);
mysqli_stmt_bind_param($stmt, "i", $employee['id']);
mysqli_stmt_execute($stmt);
$unread_count = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['count'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Faculty Portal</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="apply-leave.php"><i class="fas fa-plus-circle"></i> Apply Leave</a></li>
                <li><a href="applications.php" class="active"><i class="fas fa-file-alt"></i> My Applications</a></li>
                <li><a href="notifications.php">
                    <i class="fas fa-bell"></i> Notifications
                    <?php if($unread_count > 0): ?>
                        <span class="badge badge-danger"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>My Leave Applications</h1>
                <a href="apply-leave.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> New Application
                </a>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Filters -->
            <div class="filters">
                <form method="GET" class="filter-form">
                    <div class="filter-group">
                        <label for="year">Year:</label>
                        <select name="year" id="year">
                            <?php for($y = date('Y'); $y >= date('Y')-4; $y--): ?>
                                <option value="<?php echo $y; ?>" <?php echo $year_filter == $y ? 'selected' : ''; ?>>
                                    <?php echo $y; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="status">Status:</label>
                        <select name="status" id="status">
                            <option value="">All Status</option>
                            <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="approved" <?php echo $status_filter == 'approved' ? 'selected' : ''; ?>>Approved</option>
                            <option value="rejected" <?php echo $status_filter == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="leave_type">Leave Type:</label>
                        <select name="leave_type" id="leave_type">
                            <option value="">All Types</option>
                            <?php while($type = mysqli_fetch_assoc($leave_types)): ?>
                                <option value="<?php echo $type['id']; ?>" <?php echo $leave_type_filter == $type['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($type['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="filter-actions">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="applications.php" class="btn btn-secondary">Reset</a>
                    </div>
                </form>
            </div>

            <div class="content-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Leave Type</th>
                            <th>From Date</th>
                            <th>To Date</th>
                            <th>Days</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Applied On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($row['from_date'])); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($row['to_date'])); ?></td>
                                <td><?php echo $row['days']; ?></td>
                                <td>
                                    <span class="tooltip" data-tooltip="<?php echo htmlspecialchars($row['reason']); ?>">
                                        <?php echo strlen($row['reason']) > 30 ? substr(htmlspecialchars($row['reason']), 0, 30) . '...' : htmlspecialchars($row['reason']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo $row['status'] == 'approved' ? 'success' : 
                                            ($row['status'] == 'rejected' ? 'danger' : 'warning'); 
                                    ?>">
                                        <?php echo ucfirst($row['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('Y-m-d H:i', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <?php if($row['status'] == 'pending'): ?>
                                        <button class="btn btn-danger btn-sm" onclick="cancelApplication(<?php echo $row['id']; ?>)" title="Cancel Application">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?php if($row['attachment'] && $row['requires_attachment']): ?>
                                        <a href="../uploads/<?php echo htmlspecialchars($row['attachment']); ?>" class="btn btn-info btn-sm" target="_blank" title="View Attachment">
                                            <i class="fas fa-paperclip"></i>
                                        </a>
                                    <?php endif; ?>
                                    <?php if($row['remarks']): ?>
                                        <span class="tooltip" data-tooltip="Remarks: <?php echo htmlspecialchars($row['remarks']); ?>">
                                            <i class="fas fa-comment-alt"></i>
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <style>
    .filters {
        background: white;
        padding: 20px;
        margin-bottom: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .filter-form {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        align-items: flex-end;
    }
    .filter-group {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }
    .filter-actions {
        display: flex;
        gap: 10px;
    }
    .tooltip {
        position: relative;
        cursor: pointer;
    }
    .tooltip:hover:after {
        content: attr(data-tooltip);
        position: absolute;
        bottom: 100%;
        left: 50%;
        transform: translateX(-50%);
        background: #333;
        color: white;
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 1;
    }
    .badge {
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
    }
    .badge-success { background: #28a745; color: white; }
    .badge-danger { background: #dc3545; color: white; }
    .badge-warning { background: #ffc107; color: black; }
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    </style>

    <script>
    function cancelApplication(id) {
        if(confirm('Are you sure you want to cancel this leave application?')) {
            window.location.href = `cancel-application.php?id=${id}`;
        }
    }
    </script>
</body>
</html> 