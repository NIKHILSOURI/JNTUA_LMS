<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is faculty
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "faculty"){
    header("location: ../index.php");
    exit;
}

// Get employee ID and details
$employee_sql = "SELECT id FROM employees WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $employee_sql);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$employee_result = mysqli_stmt_get_result($stmt);
$employee = mysqli_fetch_assoc($employee_result);

// Add error handling for employee details
if (!$employee) {
    // Redirect or show an error message if no employee found
    $_SESSION['error'] = "Employee details not found.";
    header("location: ../index.php");
    exit;
}

// Ensure employee ID exists with a default value
$employee = array_merge([
    'id' => 0
], $employee ?? []);

// Get leave types with balances
$leave_types_sql = "SELECT lt.*, COALESCE(lb.leaves_taken, 0) as leaves_taken, 
                           COALESCE(lb.total_leaves, lt.max_days) as total_leaves,
                           lt.max_days
                    FROM leave_types lt
                    LEFT JOIN leave_balances lb ON lt.id = lb.leave_type_id 
                    AND lb.employee_id = ? AND lb.year = YEAR(CURRENT_DATE)
                    ORDER BY lt.name";
$stmt = mysqli_prepare($conn, $leave_types_sql);
mysqli_stmt_bind_param($stmt, "i", $employee['id']);
mysqli_stmt_execute($stmt);
$leave_types = mysqli_stmt_get_result($stmt);

// Check if leave types are empty
if (mysqli_num_rows($leave_types) == 0) {
    $_SESSION['error'] = "No leave types found. Please contact the administrator.";
}

// Get unread notifications count
$unread_sql = "SELECT COUNT(*) as count FROM notifications WHERE employee_id = ? AND is_read = 0";
$stmt = mysqli_prepare($conn, $unread_sql);
mysqli_stmt_bind_param($stmt, "i", $employee['id']);
mysqli_stmt_execute($stmt);
$unread_count = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['count'];

// Ensure error logging is enabled
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);
ini_set('error_log', '../logs/php_errors.log');

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $leave_type_id = mysqli_real_escape_string($conn, $_POST['leave_type_id']);
    $from_date = mysqli_real_escape_string($conn, $_POST['from_date']);
    $to_date = mysqli_real_escape_string($conn, $_POST['to_date']);
    $reason = mysqli_real_escape_string($conn, $_POST['reason']);
    $days = (strtotime($to_date) - strtotime($from_date)) / (60 * 60 * 24) + 1;
    
    // Validate dates
    if(strtotime($from_date) > strtotime($to_date)) {
        $_SESSION['error'] = "From date cannot be after to date.";
        header("location: apply-leave.php");
        exit();
    }

    // Check leave balance
    $balance_sql = "SELECT lt.max_days, COALESCE(lb.total_leaves, lt.max_days) as total_leaves,
                           COALESCE(lb.leaves_taken, 0) as leaves_taken,
                           lt.requires_attachment 
                   FROM leave_types lt
                   LEFT JOIN leave_balances lb ON lt.id = lb.leave_type_id 
                   AND lb.employee_id = ? AND lb.year = YEAR(CURRENT_DATE)
                   WHERE lt.id = ?";
    $stmt = mysqli_prepare($conn, $balance_sql);
    mysqli_stmt_bind_param($stmt, "ii", $employee['id'], $leave_type_id);
    mysqli_stmt_execute($stmt);
    $balance = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if(($balance['leaves_taken'] + $days) > $balance['total_leaves']) {
        $_SESSION['error'] = "Insufficient leave balance.";
        header("location: apply-leave.php");
        exit();
    }

    // Handle file upload if required
    $attachment = null;
    if($balance['requires_attachment']) {
        if(!isset($_FILES['attachment']) || $_FILES['attachment']['error'] === UPLOAD_ERR_NO_FILE) {
            $_SESSION['error'] = "Attachment is required for this leave type.";
            header("location: apply-leave.php");
            exit();
        }

        $file = $_FILES['attachment'];
        
        // Validate file upload errors
        switch ($file['error']) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_NO_FILE:
                $_SESSION['error'] = "No file was uploaded.";
                header("location: apply-leave.php");
                exit();
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                $_SESSION['error'] = "File is too large. Maximum file size is " . ini_get('upload_max_filesize');
                header("location: apply-leave.php");
                exit();
            default:
                $_SESSION['error'] = "File upload failed. Error code: " . $file['error'];
                header("location: apply-leave.php");
                exit();
        }

        // Validate file size (max 5MB)
        $max_file_size = 5 * 1024 * 1024; // 5MB
        if ($file['size'] > $max_file_size) {
            $_SESSION['error'] = "File is too large. Maximum file size is 5MB.";
            header("location: apply-leave.php");
            exit();
        }

        $allowed_types = ['pdf', 'jpg', 'jpeg', 'png'];
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if(!in_array($file_ext, $allowed_types)) {
            $_SESSION['error'] = "Invalid file type. Only PDF, JPG, JPEG, and PNG files are allowed.";
            header("location: apply-leave.php");
            exit();
        }

        // Generate unique filename
        $attachment = uniqid() . '.' . $file_ext;
        $upload_path = "../uploads/" . $attachment;

        // Ensure uploads directory exists and is writable
        if (!is_dir("../uploads")) {
            mkdir("../uploads", 0755, true);
        }

        // Move uploaded file with additional error checking
        if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
            error_log("File upload failed: Unable to move uploaded file to $upload_path");
            $_SESSION['error'] = "File upload failed. Please try again.";
            header("location: apply-leave.php");
            exit();
        }

        // Optional: Add file permission setting
        chmod($upload_path, 0644);
    }

    // Insert application
    $sql = "INSERT INTO leave_applications (employee_id, leave_type_id, from_date, to_date, days, reason, attachment, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "iississ", $employee['id'], $leave_type_id, $from_date, $to_date, $days, $reason, $attachment);

    if(mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Leave application submitted successfully.";
        header("location: applications.php");
        exit();
    } else {
        $_SESSION['error'] = "Error submitting leave application.";
        header("location: apply-leave.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply Leave - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Faculty Portal</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="apply-leave.php" class="active"><i class="fas fa-plus-circle"></i> Apply Leave</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> My Applications</a></li>
                <li><a href="notifications.php">
                    <i class="fas fa-bell"></i> Notifications
                    <?php if($unread_count > 0): ?>
                        <span class="badge badge-danger"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Apply for Leave</h1>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="content-wrapper">
                <div class="leave-balances">
                    <h2>Current Leave Balances</h2>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Leave Type</th>
                                <th>Available</th>
                                <th>Taken</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            mysqli_data_seek($leave_types, 0);
                            while($type = mysqli_fetch_assoc($leave_types)): 
                                $available = $type['total_leaves'] - $type['leaves_taken'];
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($type['name']); ?></td>
                                    <td><?php echo $available; ?></td>
                                    <td><?php echo $type['leaves_taken']; ?></td>
                                    <td><?php echo $type['total_leaves']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form" enctype="multipart/form-data">
                    <div class="form-section">
                        <h2>Leave Application Form</h2>
                        
                        <div class="form-group">
                            <label for="leave_type_id">Leave Type</label>
                            <select id="leave_type_id" name="leave_type_id" required onchange="checkAttachment(this)">
                                <option value="">Select Leave Type</option>
                                <?php 
                                mysqli_data_seek($leave_types, 0);
                                while($type = mysqli_fetch_assoc($leave_types)): 
                                ?>
                                    <option value="<?php echo $type['id']; ?>" 
                                            data-requires-attachment="<?php echo $type['requires_attachment']; ?>"
                                            data-balance="<?php echo $type['max_days'] - $type['leaves_taken']; ?>">
                                        <?php echo htmlspecialchars($type['name']); ?> 
                                        (<?php echo $type['max_days'] - $type['leaves_taken']; ?> days available)
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="from_date">From Date</label>
                                <input type="date" id="from_date" name="from_date" required min="<?php echo date('Y-m-d'); ?>" onchange="calculateDays()">
                            </div>

                            <div class="form-group">
                                <label for="to_date">To Date</label>
                                <input type="date" id="to_date" name="to_date" required min="<?php echo date('Y-m-d'); ?>" onchange="calculateDays()">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="days">Number of Days</label>
                            <input type="text" id="days" readonly>
                            <small>This will be calculated automatically</small>
                        </div>

                        <div class="form-group">
                            <label for="reason">Reason for Leave</label>
                            <textarea id="reason" name="reason" required rows="4"></textarea>
                        </div>

                        <div class="form-group" id="attachment-group" style="display: none;">
                            <label for="attachment">Attachment</label>
                            <input type="file" id="attachment" name="attachment" accept=".pdf,.jpg,.jpeg,.png">
                            <small>Allowed file types: PDF, JPG, JPEG, PNG</small>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Submit Application</button>
                        <a href="applications.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <style>
    .leave-balances {
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin-bottom: 20px;
    }
    .form-section {
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    .form-actions {
        margin-top: 20px;
        display: flex;
        gap: 10px;
    }
    </style>

    <script>
    function calculateDays() {
        const fromDate = document.getElementById('from_date').value;
        const toDate = document.getElementById('to_date').value;
        
        if(fromDate && toDate) {
            const from = new Date(fromDate);
            const to = new Date(toDate);
            const days = Math.floor((to - from) / (1000 * 60 * 60 * 24)) + 1;
            
            document.getElementById('days').value = days > 0 ? days : 0;
            
            // Check against available balance
            const leaveType = document.getElementById('leave_type_id');
            const selectedOption = leaveType.options[leaveType.selectedIndex];
            if(selectedOption.value) {
                const balance = parseInt(selectedOption.dataset.balance);
                if(days > balance) {
                    alert('Warning: The selected number of days exceeds your available balance.');
                }
            }
        }
    }

    function checkAttachment(select) {
        const selectedOption = select.options[select.selectedIndex];
        const attachmentGroup = document.getElementById('attachment-group');
        const attachmentInput = document.getElementById('attachment');
        
        if(selectedOption.dataset.requiresAttachment === '1') {
            attachmentGroup.style.display = 'block';
            attachmentInput.required = true;
        } else {
            attachmentGroup.style.display = 'none';
            attachmentInput.required = false;
        }
    }
    </script>
</body>
</html> 