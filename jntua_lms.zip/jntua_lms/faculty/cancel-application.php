<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is faculty
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "faculty"){
    header("location: ../index.php");
    exit;
}

if(!isset($_GET['id'])) {
    $_SESSION['error'] = "Invalid request.";
    header("location: applications.php");
    exit;
}

// Get employee ID
$employee_sql = "SELECT id FROM employees WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $employee_sql);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$employee = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Verify application belongs to the faculty and is pending
$verify_sql = "SELECT id FROM leave_applications 
               WHERE id = ? AND employee_id = ? AND status = 'pending'";
$stmt = mysqli_prepare($conn, $verify_sql);
mysqli_stmt_bind_param($stmt, "ii", $_GET['id'], $employee['id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "You can only cancel your own pending applications.";
    header("location: applications.php");
    exit;
}

// Cancel the application
$cancel_sql = "UPDATE leave_applications SET status = 'cancelled', updated_at = NOW() WHERE id = ?";
$stmt = mysqli_prepare($conn, $cancel_sql);
mysqli_stmt_bind_param($stmt, "i", $_GET['id']);

if(mysqli_stmt_execute($stmt)) {
    $_SESSION['success'] = "Leave application cancelled successfully.";
} else {
    $_SESSION['error'] = "Error cancelling leave application.";
}

header("location: applications.php");
exit;
?> 