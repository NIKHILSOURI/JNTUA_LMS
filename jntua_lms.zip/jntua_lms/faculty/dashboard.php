<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is faculty
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "faculty"){
    header("location: ../index.php");
    exit;
}

// Get employee details
$employee_sql = "SELECT e.*, d.name as department_name, dg.name as designation_name 
                FROM employees e 
                JOIN departments d ON e.department_id = d.id 
                JOIN designations dg ON e.designation_id = dg.id 
                WHERE e.user_id = ?";
$stmt = mysqli_prepare($conn, $employee_sql);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$employee_result = mysqli_stmt_get_result($stmt);
$employee = mysqli_fetch_assoc($employee_result);

// Add error handling for employee details
if (!$employee) {
    // Redirect or show an error message if no employee found
    $_SESSION['error'] = "Employee details not found.";
    header("location: ../index.php");
    exit;
}

// Ensure all required keys exist with default values
$employee = array_merge([
    'name' => 'Unknown',
    'department_name' => 'N/A',
    'designation_name' => 'N/A',
    'employee_id' => 'N/A',
    'id' => 0
], $employee ?? []);

// Get leave balances for current year
$balance_sql = "SELECT lt.name, lb.total_leaves, lb.leaves_taken 
                FROM leave_balances lb
                JOIN leave_types lt ON lb.leave_type_id = lt.id
                WHERE lb.employee_id = ? AND lb.year = YEAR(CURRENT_DATE)
                ORDER BY lt.name";
$stmt = mysqli_prepare($conn, $balance_sql);
mysqli_stmt_bind_param($stmt, "i", $employee['id']);
mysqli_stmt_execute($stmt);
$balances = mysqli_stmt_get_result($stmt);

// Get recent leave applications
$applications_sql = "SELECT la.*, lt.name as leave_type
                    FROM leave_applications la
                    JOIN leave_types lt ON la.leave_type_id = lt.id
                    WHERE la.employee_id = ?
                    ORDER BY la.created_at DESC
                    LIMIT 5";
$stmt = mysqli_prepare($conn, $applications_sql);
mysqli_stmt_bind_param($stmt, "i", $employee['id']);
mysqli_stmt_execute($stmt);
$recent_applications = mysqli_stmt_get_result($stmt);

// Get application statistics
$stats_sql = "SELECT 
                COUNT(*) as total_applications,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
              FROM leave_applications 
              WHERE employee_id = ? AND YEAR(created_at) = YEAR(CURRENT_DATE)";
$stmt = mysqli_prepare($conn, $stats_sql);
mysqli_stmt_bind_param($stmt, "i", $employee['id']);
mysqli_stmt_execute($stmt);
$stats = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Get unread notifications count
$unread_sql = "SELECT COUNT(*) as count FROM notifications WHERE employee_id = ? AND is_read = 0";
$stmt = mysqli_prepare($conn, $unread_sql);
mysqli_stmt_bind_param($stmt, "i", $employee['id']);
mysqli_stmt_execute($stmt);
$unread_count = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Faculty Portal</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="apply-leave.php"><i class="fas fa-plus-circle"></i> Apply Leave</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> My Applications</a></li>
                <li><a href="notifications.php">
                    <i class="fas fa-bell"></i> Notifications
                    <?php if($unread_count > 0): ?>
                        <span class="badge badge-danger"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="header">
                <h1>Welcome, <?php echo htmlspecialchars($employee['name']); ?></h1>
            </div>

            <div class="profile-summary">
                <div class="info-card">
                    <div class="info-item">
                        <span class="label">Department:</span>
                        <span class="value"><?php echo htmlspecialchars($employee['department_name']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="label">Designation:</span>
                        <span class="value"><?php echo htmlspecialchars($employee['designation_name']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="label">Employee ID:</span>
                        <span class="value"><?php echo htmlspecialchars($employee['employee_id']); ?></span>
                    </div>
                </div>
            </div>

            <div class="quick-actions">
                <a href="apply-leave.php" class="action-card">
                    <i class="fas fa-plus-circle"></i>
                    <span>Apply for Leave</span>
                </a>
                <a href="applications.php" class="action-card">
                    <i class="fas fa-list"></i>
                    <span>View Applications</span>
                </a>
                <a href="profile.php" class="action-card">
                    <i class="fas fa-user-edit"></i>
                    <span>Update Profile</span>
                </a>
            </div>

            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h3>Leave Balances</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Leave Type</th>
                                <th>Available</th>
                                <th>Taken</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($balance = mysqli_fetch_assoc($balances)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($balance['name']); ?></td>
                                    <td><?php echo $balance['total_leaves'] - $balance['leaves_taken']; ?></td>
                                    <td><?php echo $balance['leaves_taken']; ?></td>
                                    <td><?php echo $balance['total_leaves']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <div class="dashboard-card">
                    <h3>Leave Application Statistics</h3>
                    <div class="stats-grid">
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $stats['total_applications']; ?></span>
                            <span class="stat-label">Total Applications</span>
                        </div>
                        <div class="stat-item approved">
                            <span class="stat-value"><?php echo $stats['approved']; ?></span>
                            <span class="stat-label">Approved</span>
                        </div>
                        <div class="stat-item rejected">
                            <span class="stat-value"><?php echo $stats['rejected']; ?></span>
                            <span class="stat-label">Rejected</span>
                        </div>
                        <div class="stat-item pending">
                            <span class="stat-value"><?php echo $stats['pending']; ?></span>
                            <span class="stat-label">Pending</span>
                        </div>
                    </div>
                </div>

                <div class="dashboard-card">
                    <h3>Recent Leave Applications</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Leave Type</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Days</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($app = mysqli_fetch_assoc($recent_applications)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($app['leave_type']); ?></td>
                                    <td><?php echo date('Y-m-d', strtotime($app['from_date'])); ?></td>
                                    <td><?php echo date('Y-m-d', strtotime($app['to_date'])); ?></td>
                                    <td><?php echo $app['days']; ?></td>
                                    <td>
                                        <span class="badge badge-<?php 
                                            echo $app['status'] == 'approved' ? 'success' : 
                                                ($app['status'] == 'rejected' ? 'danger' : 'warning'); 
                                        ?>">
                                            <?php echo ucfirst($app['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <style>
    .profile-summary {
        background: white;
        padding: 20px;
        margin: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .info-card {
        display: flex;
        gap: 30px;
    }
    .info-item {
        display: flex;
        flex-direction: column;
    }
    .info-item .label {
        font-size: 14px;
        color: #6c757d;
    }
    .info-item .value {
        font-size: 16px;
        font-weight: bold;
    }
    .quick-actions {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        padding: 20px;
    }
    .action-card {
        background: white;
        padding: 20px;
        border-radius: 8px;
        text-align: center;
        text-decoration: none;
        color: #333;
        transition: transform 0.2s;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .action-card:hover {
        transform: translateY(-5px);
    }
    .action-card i {
        font-size: 24px;
        margin-bottom: 10px;
        color: #007bff;
    }
    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        padding: 20px;
    }
    .dashboard-card {
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .dashboard-card:last-child {
        grid-column: 1 / -1;
    }
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 15px;
        margin-top: 15px;
    }
    .stat-item {
        text-align: center;
        padding: 15px;
        border-radius: 8px;
        background: #f8f9fa;
    }
    .stat-value {
        display: block;
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 5px;
    }
    .stat-label {
        font-size: 14px;
        color: #6c757d;
    }
    .stat-item.approved { background: #d4edda; }
    .stat-item.rejected { background: #f8d7da; }
    .stat-item.pending { background: #fff3cd; }
    .badge {
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
    }
    .badge-success { background: #28a745; color: white; }
    .badge-danger { background: #dc3545; color: white; }
    .badge-warning { background: #ffc107; color: black; }
    </style>
</body>
</html> 