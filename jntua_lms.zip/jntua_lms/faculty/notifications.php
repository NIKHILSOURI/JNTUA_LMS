<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is faculty
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "faculty"){
    header("location: ../index.php");
    exit;
}

// Get employee ID
$employee_sql = "SELECT id FROM employees WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $employee_sql);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$employee = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Mark notifications as read if requested
if(isset($_GET['mark_read']) && $_GET['mark_read'] == 'all') {
    $update_sql = "UPDATE notifications SET is_read = 1 WHERE employee_id = ?";
    $stmt = mysqli_prepare($conn, $update_sql);
    mysqli_stmt_bind_param($stmt, "i", $employee['id']);
    mysqli_stmt_execute($stmt);
    header("location: notifications.php");
    exit();
}

// Fetch notifications
$notifications_sql = "SELECT n.*, la.from_date, la.to_date, lt.name as leave_type
                     FROM notifications n
                     LEFT JOIN leave_applications la ON n.application_id = la.id
                     LEFT JOIN leave_types lt ON la.leave_type_id = lt.id
                     WHERE n.employee_id = ?
                     ORDER BY n.created_at DESC";
$stmt = mysqli_prepare($conn, $notifications_sql);
mysqli_stmt_bind_param($stmt, "i", $employee['id']);
mysqli_stmt_execute($stmt);
$notifications = mysqli_stmt_get_result($stmt);

// Get unread count for badge
$unread_sql = "SELECT COUNT(*) as count FROM notifications WHERE employee_id = ? AND is_read = 0";
$stmt = mysqli_prepare($conn, $unread_sql);
mysqli_stmt_bind_param($stmt, "i", $employee['id']);
mysqli_stmt_execute($stmt);
$unread_count = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Faculty Portal</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="apply-leave.php"><i class="fas fa-plus-circle"></i> Apply Leave</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> My Applications</a></li>
                <li><a href="notifications.php" class="active">
                    <i class="fas fa-bell"></i> Notifications
                    <?php if($unread_count > 0): ?>
                        <span class="badge badge-danger"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Notifications</h1>
                <?php if($unread_count > 0): ?>
                    <a href="?mark_read=all" class="btn btn-secondary">
                        <i class="fas fa-check-double"></i> Mark All as Read
                    </a>
                <?php endif; ?>
            </div>

            <div class="content-wrapper">
                <div class="notifications-container">
                    <?php if(mysqli_num_rows($notifications) > 0): ?>
                        <?php while($notification = mysqli_fetch_assoc($notifications)): ?>
                            <div class="notification-item <?php echo $notification['is_read'] ? '' : 'unread'; ?>">
                                <div class="notification-icon">
                                    <?php if($notification['type'] == 'status_update'): ?>
                                        <i class="fas fa-clipboard-check"></i>
                                    <?php elseif($notification['type'] == 'reminder'): ?>
                                        <i class="fas fa-clock"></i>
                                    <?php else: ?>
                                        <i class="fas fa-bell"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="notification-content">
                                    <div class="notification-message">
                                        <?php echo htmlspecialchars($notification['message']); ?>
                                    </div>
                                    <?php if($notification['leave_type']): ?>
                                        <div class="notification-details">
                                            <?php echo htmlspecialchars($notification['leave_type']); ?> Leave
                                            (<?php echo date('M d', strtotime($notification['from_date'])); ?> - 
                                            <?php echo date('M d, Y', strtotime($notification['to_date'])); ?>)
                                        </div>
                                    <?php endif; ?>
                                    <div class="notification-time">
                                        <?php 
                                        $date = new DateTime($notification['created_at']);
                                        $now = new DateTime();
                                        $interval = $date->diff($now);
                                        
                                        if($interval->d == 0) {
                                            if($interval->h == 0) {
                                                echo $interval->i . " minutes ago";
                                            } else {
                                                echo $interval->h . " hours ago";
                                            }
                                        } elseif($interval->d == 1) {
                                            echo "Yesterday";
                                        } else {
                                            echo date('M d, Y', strtotime($notification['created_at']));
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="no-notifications">
                            <i class="fas fa-bell-slash"></i>
                            <p>No notifications to display</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <style>
    .notifications-container {
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        overflow: hidden;
    }
    .notification-item {
        display: flex;
        padding: 20px;
        border-bottom: 1px solid #eee;
        transition: background-color 0.2s;
    }
    .notification-item:last-child {
        border-bottom: none;
    }
    .notification-item.unread {
        background-color: #f8f9fa;
    }
    .notification-icon {
        width: 40px;
        height: 40px;
        background: #e9ecef;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 15px;
    }
    .notification-icon i {
        color: #6c757d;
        font-size: 1.2em;
    }
    .notification-content {
        flex: 1;
    }
    .notification-message {
        color: #333;
        margin-bottom: 5px;
    }
    .notification-details {
        color: #6c757d;
        font-size: 0.9em;
        margin-bottom: 5px;
    }
    .notification-time {
        color: #adb5bd;
        font-size: 0.8em;
    }
    .no-notifications {
        text-align: center;
        padding: 40px 20px;
        color: #6c757d;
    }
    .no-notifications i {
        font-size: 3em;
        margin-bottom: 10px;
        opacity: 0.5;
    }
    .badge {
        position: absolute;
        top: -5px;
        right: -5px;
        min-width: 18px;
        height: 18px;
        line-height: 18px;
        text-align: center;
        border-radius: 9px;
        font-size: 11px;
        font-weight: bold;
        padding: 0 5px;
    }
    .nav-menu li {
        position: relative;
    }
    </style>
</body>
</html> 