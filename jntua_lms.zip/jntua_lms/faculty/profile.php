<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is faculty
if(!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "faculty"){
    header("location: ../index.php");
    exit;
}

// Get employee details
$employee_sql = "SELECT e.*, d.name as department_name, d.code as department_code, 
                        dg.name as designation_name, u.username 
                FROM employees e 
                JOIN departments d ON e.department_id = d.id 
                JOIN designations dg ON e.designation_id = dg.id 
                JOIN users u ON e.user_id = u.id
                WHERE e.user_id = ?";

// Validate session and user role
if (!isset($_SESSION["loggedin"]) || $_SESSION["role"] != "faculty") {
    $_SESSION['error'] = "Unauthorized access. Please log in as a faculty member.";
    header("location: ../index.php");
    exit;
}

// Validate user_id
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    $_SESSION['error'] = "Invalid user session. Please log in again.";
    header("location: ../index.php");
    exit;
}

// Detailed error logging
error_log("Profile Page - Attempting to fetch details for User ID: " . $_SESSION['user_id']);

$stmt = mysqli_prepare($conn, $employee_sql);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$employee_result = mysqli_stmt_get_result($stmt);

// Check for query execution errors
if (!$employee_result) {
    $error_message = "Database query error: " . mysqli_error($conn);
    error_log($error_message);
    $_SESSION['error'] = $error_message;
    header("location: ../index.php");
    exit;
}

$employee = mysqli_fetch_assoc($employee_result);

// Detailed investigation if no employee found
if (!$employee) {
    // Check if user exists
    $user_check_sql = "SELECT * FROM users WHERE id = ? AND role = 'faculty'";
    $user_stmt = mysqli_prepare($conn, $user_check_sql);
    mysqli_stmt_bind_param($user_stmt, "i", $_SESSION['user_id']);
    mysqli_stmt_execute($user_stmt);
    $user_result = mysqli_stmt_get_result($user_stmt);
    $user = mysqli_fetch_assoc($user_result);

    // Check if employee record exists
    $emp_check_sql = "SELECT * FROM employees WHERE user_id = ?";
    $emp_stmt = mysqli_prepare($conn, $emp_check_sql);
    mysqli_stmt_bind_param($emp_stmt, "i", $_SESSION['user_id']);
    mysqli_stmt_execute($emp_stmt);
    $emp_result = mysqli_stmt_get_result($emp_stmt);
    $emp = mysqli_fetch_assoc($emp_result);

    // Log detailed error information
    error_log("Profile Page - Detailed Error Investigation:");
    error_log("User Details: " . print_r($user, true));
    error_log("Employee Details: " . print_r($emp, true));

    // Provide a more informative error message
    if (!$user) {
        $_SESSION['error'] = "No faculty user found with ID: " . $_SESSION['user_id'] . ". Please contact the administrator.";
    } elseif (!$emp) {
        $_SESSION['error'] = "No employee record found for user ID: " . $_SESSION['user_id'] . ". Please contact the administrator to create your employee profile.";
    } else {
        $_SESSION['error'] = "Unable to retrieve employee details. An unexpected error occurred.";
    }

    header("location: ../index.php");
    exit;
}

// Ensure all required keys exist with default values
$employee = array_merge([
    'name' => 'Unknown',
    'employee_id' => 'N/A',
    'department_name' => 'N/A',
    'department_code' => 'N/A',
    'designation_name' => 'N/A',
    'joining_date' => 'N/A',
    'email' => '',
    'phone' => '',
    'id' => 0
], $employee ?? []);

// Calculate years of service
$joining_date = new DateTime($employee['joining_date']);
$current_date = new DateTime();
$years_of_service = $joining_date->diff($current_date)->y;

// Get unread notifications count
$unread_sql = "SELECT COUNT(*) as count FROM notifications WHERE employee_id = ? AND is_read = 0";
$stmt = mysqli_prepare($conn, $unread_sql);
mysqli_stmt_bind_param($stmt, "i", $employee['id']);
mysqli_stmt_execute($stmt);
$unread_count = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['count'];

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate input
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    
    // Start transaction
    mysqli_begin_transaction($conn);

    try {
        // Update employee details
        $update_sql = "UPDATE employees SET 
                      name = ?, 
                      email = ?, 
                      phone = ?
                      WHERE user_id = ?";
        
        $stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($stmt, "sssi", $name, $email, $phone, $_SESSION['user_id']);
        mysqli_stmt_execute($stmt);

        // Update password if provided
        if(!empty($_POST['new_password']) && !empty($_POST['current_password'])) {
            // Verify current password
            $verify_sql = "SELECT password FROM users WHERE id = ?";
            $stmt = mysqli_prepare($conn, $verify_sql);
            mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
            mysqli_stmt_execute($stmt);
            $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            
            if(password_verify($_POST['current_password'], $user['password'])) {
                $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                $pass_sql = "UPDATE users SET password = ? WHERE id = ?";
                $stmt = mysqli_prepare($conn, $pass_sql);
                mysqli_stmt_bind_param($stmt, "si", $new_password, $_SESSION['user_id']);
                mysqli_stmt_execute($stmt);
                
                mysqli_commit($conn);
                $_SESSION['success'] = "Profile updated successfully.";
            } else {
                mysqli_rollback($conn);
                $_SESSION['error'] = "Current password is incorrect.";
            }
        } else {
            mysqli_commit($conn);
            $_SESSION['success'] = "Profile updated successfully.";
        }
        
        header("location: profile.php");
        exit();
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = "Error updating profile. Please try again.";
        header("location: profile.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - JNTUA LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-container">
                <img src="../assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h2>Faculty Portal</h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="apply-leave.php"><i class="fas fa-plus-circle"></i> Apply Leave</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> My Applications</a></li>
                <li><a href="notifications.php">
                    <i class="fas fa-bell"></i> Notifications
                    <?php if($unread_count > 0): ?>
                        <span class="badge badge-danger"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </a></li>
                <li><a href="profile.php" class="active"><i class="fas fa-user"></i> My Profile</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>My Profile</h1>
            </div>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="content-wrapper">
                <div class="profile-container">
                    <div class="profile-section">
                        <h2>Personal Information</h2>
                        <div class="info-grid">
                            <div class="info-item">
                                <span class="label">Employee ID:</span>
                                <span class="value"><?php echo htmlspecialchars($employee['employee_id']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">Department:</span>
                                <span class="value">
                                    <?php echo htmlspecialchars($employee['department_name']); ?> 
                                    <small>(<?php echo htmlspecialchars($employee['department_code']); ?>)</small>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="label">Designation:</span>
                                <span class="value"><?php echo htmlspecialchars($employee['designation_name']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">Joining Date:</span>
                                <span class="value"><?php echo htmlspecialchars($employee['joining_date']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="label">Years of Service:</span>
                                <span class="value"><?php echo $years_of_service; ?> years</span>
                            </div>
                            <div class="info-item">
                                <span class="label">Username:</span>
                                <span class="value"><?php echo htmlspecialchars($employee['username']); ?></span>
                            </div>
                        </div>
                    </div>

                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form">
                        <div class="form-section">
                            <h2>Update Profile</h2>
                            <div class="form-group">
                                <label for="name">Full Name</label>
                                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($employee['name']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($employee['email']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($employee['phone']); ?>" required>
                            </div>
                        </div>

                        <div class="form-section">
                            <h2>Change Password</h2>
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" id="current_password" name="current_password">
                            </div>

                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password">
                                <small>Leave blank to keep current password</small>
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Update Profile</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <style>
    .profile-container {
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        padding: 20px;
    }
    .profile-section {
        margin-bottom: 30px;
        padding-bottom: 20px;
        border-bottom: 1px solid #eee;
    }
    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-top: 15px;
    }
    .info-item {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }
    .info-item .label {
        font-size: 14px;
        color: #6c757d;
    }
    .info-item .value {
        font-size: 16px;
        font-weight: bold;
    }
    .form-section {
        margin-bottom: 30px;
    }
    .form-section h2 {
        margin-bottom: 20px;
        color: #333;
        font-size: 1.2em;
    }
    .form-group small {
        display: block;
        margin-top: 5px;
        color: #6c757d;
        font-size: 12px;
    }
    .form-actions {
        margin-top: 30px;
        padding-top: 20px;
        border-top: 1px solid #eee;
    }
    </style>
</body>
</html> 