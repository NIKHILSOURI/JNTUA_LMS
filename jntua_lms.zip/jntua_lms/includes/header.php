<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JNTUA Faculty Leave Management System</title>
    <!-- Favicon and Logo -->
    <link rel="icon" href="assets/images/jntua-logo.png" type="image/png">
    
    <!-- CSS and other head elements -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo-container">
                <img src="assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
                <h1>Faculty Leave Management System</h1>
            </div>
            <!-- Navigation menu will be added here -->
        </div>
    </header>
</body>
</html> 