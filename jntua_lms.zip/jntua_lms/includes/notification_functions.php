<?php
require_once '../config/database.php';

/**
 * Create a new notification for a faculty member
 */
function create_notification($employee_id, $message, $type = 'general', $leave_application_id = null) {
    global $conn;
    
    $sql = "INSERT INTO notifications (employee_id, message, type, leave_application_id, created_at) 
            VALUES (?, ?, ?, ?, NOW())";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "issi", $employee_id, $message, $type, $leave_application_id);
    return mysqli_stmt_execute($stmt);
}

/**
 * Create a notification for leave application status update
 */
function notify_leave_status($application_id, $status, $remarks = '') {
    global $conn;
    
    // Get application details
    $sql = "SELECT la.*, e.id as employee_id, lt.name as leave_type 
            FROM leave_applications la
            JOIN employees e ON la.employee_id = e.id
            JOIN leave_types lt ON la.leave_type_id = lt.id
            WHERE la.id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $application_id);
    mysqli_stmt_execute($stmt);
    $application = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    
    if(!$application) return false;
    
    // Create status update message
    $message = "Your {$application['leave_type']} leave application has been " . strtolower($status);
    if($remarks) {
        $message .= ". Remarks: " . $remarks;
    }
    
    return create_notification(
        $application['employee_id'],
        $message,
        'status_update',
        $application_id
    );
}

/**
 * Create a reminder notification for upcoming leave
 */
function notify_upcoming_leave($application_id) {
    global $conn;
    
    // Get application details
    $sql = "SELECT la.*, e.id as employee_id, lt.name as leave_type 
            FROM leave_applications la
            JOIN employees e ON la.employee_id = e.id
            JOIN leave_types lt ON la.leave_type_id = lt.id
            WHERE la.id = ? AND la.status = 'approved'";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $application_id);
    mysqli_stmt_execute($stmt);
    $application = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    
    if(!$application) return false;
    
    $message = "Reminder: Your {$application['leave_type']} leave starts tomorrow";
    
    return create_notification(
        $application['employee_id'],
        $message,
        'reminder',
        $application_id
    );
}

/**
 * Create a notification for low leave balance
 */
function notify_low_balance($employee_id, $leave_type_id) {
    global $conn;
    
    // Get leave type details
    $sql = "SELECT lt.name, lb.max_days, lb.leaves_taken 
            FROM leave_types lt
            JOIN leave_balances lb ON lt.id = lb.leave_type_id
            WHERE lb.employee_id = ? AND lt.id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $employee_id, $leave_type_id);
    mysqli_stmt_execute($stmt);
    $balance = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    
    if(!$balance) return false;
    
    $remaining = $balance['max_days'] - $balance['leaves_taken'];
    $message = "Low balance alert: You have {$remaining} {$balance['name']} leave days remaining";
    
    return create_notification(
        $employee_id,
        $message,
        'balance_alert'
    );
}

/**
 * Mark notifications as read
 */
function mark_notifications_read($employee_id, $notification_ids = null) {
    global $conn;
    
    if($notification_ids) {
        $ids = implode(',', array_map('intval', $notification_ids));
        $sql = "UPDATE notifications SET is_read = 1 
                WHERE employee_id = ? AND id IN ({$ids})";
    } else {
        $sql = "UPDATE notifications SET is_read = 1 
                WHERE employee_id = ?";
    }
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $employee_id);
    return mysqli_stmt_execute($stmt);
}

/**
 * Comprehensive leave application status update function
 * @param int $application_id Leave application ID
 * @param string $status New status (approved/rejected)
 * @param string $remarks Optional remarks for the status change
 * @return bool Success status of the operation
 */
function process_leave_application($application_id, $status, $remarks = '') {
    global $conn;
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Get application details
        $app_sql = "SELECT la.*, e.id as employee_id, e.name as employee_name, 
                           lt.name as leave_type, lt.max_days as max_leave_days
                    FROM leave_applications la
                    JOIN employees e ON la.employee_id = e.id
                    JOIN leave_types lt ON la.leave_type_id = lt.id
                    WHERE la.id = ?";
        $stmt = mysqli_prepare($conn, $app_sql);
        mysqli_stmt_bind_param($stmt, "i", $application_id);
        mysqli_stmt_execute($stmt);
        $application = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        
        if (!$application) {
            throw new Exception("Leave application not found");
        }
        
        // Update application status
        $update_sql = "UPDATE leave_applications 
                       SET status = ?, 
                           remarks = ?, 
                           updated_at = NOW() 
                       WHERE id = ?";
        $stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($stmt, "ssi", $status, $remarks, $application_id);
        mysqli_stmt_execute($stmt);
        
        // If approved, update leave balance
        if ($status == 'approved') {
            // Update leave balance
            $balance_sql = "UPDATE leave_balances 
                            SET leaves_taken = leaves_taken + ?, 
                                updated_at = NOW() 
                            WHERE employee_id = ? 
                            AND leave_type_id = ? 
                            AND year = YEAR(CURRENT_DATE)";
            $stmt = mysqli_prepare($conn, $balance_sql);
            mysqli_stmt_bind_param($stmt, "iii", 
                $application['days'], 
                $application['employee_id'], 
                $application['leave_type_id']
            );
            mysqli_stmt_execute($stmt);
            
            // Check remaining balance
            $balance_check_sql = "SELECT max_days - leaves_taken as remaining
                                  FROM leave_balances 
                                  WHERE employee_id = ? 
                                  AND leave_type_id = ? 
                                  AND year = YEAR(CURRENT_DATE)";
            $stmt = mysqli_prepare($conn, $balance_check_sql);
            mysqli_stmt_bind_param($stmt, "ii", 
                $application['employee_id'], 
                $application['leave_type_id']
            );
            mysqli_stmt_execute($stmt);
            $balance = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            
            // Low balance notification
            if ($balance['remaining'] <= 2) {
                $low_balance_msg = "Low balance alert: You have only {$balance['remaining']} days remaining for {$application['leave_type']}";
                create_notification(
                    $application['employee_id'], 
                    $low_balance_msg, 
                    'balance_alert'
                );
            }
        }
        
        // Create notification for the faculty
        $status_msg = "Your {$application['leave_type']} leave application from {$application['from_date']} to {$application['to_date']} has been " . strtolower($status);
        if (!empty($remarks)) {
            $status_msg .= ". Remarks: " . $remarks;
        }
        
        create_notification(
            $application['employee_id'], 
            $status_msg, 
            'leave_status', 
            $application_id
        );
        
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        error_log("Leave application processing error: " . $e->getMessage());
        return false;
    }
}
?> 