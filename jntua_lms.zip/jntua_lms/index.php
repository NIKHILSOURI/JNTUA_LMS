<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JNTUA - Faculty Leave Management System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <img src="assets/images/jntua-logo.png" alt="JNTUA Logo" class="logo">
            <h1>Faculty Leave Management System</h1>
            <h2>Jawaharlal Nehru Technological University Anantapur</h2>
        </div>
        <div class="login-form">
            <?php 
            // Display error message if exists
            if(isset($_SESSION['error'])): 
            ?>
            <div class="alert alert-error">
                <?php 
                echo htmlspecialchars($_SESSION['error']); 
                // Clear the error message after displaying
                unset($_SESSION['error']); 
                ?>
            </div>
            <?php endif; ?>
            <form action="auth/login.php" method="POST">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="role">Login As:</label>
                    <select id="role" name="role" required>
                        <option value="">Select Role</option>
                        <option value="admin">Admin</option>
                        <option value="faculty">Faculty</option>
                    </select>
                </div>
                <button type="submit" class="login-btn">Login</button>
            </form>
        </div>
    </div>
    <footer>
        <p>&copy; <?php echo date('Y'); ?> JNTUA. All rights reserved.</p>
    </footer>
</body>
</html> 