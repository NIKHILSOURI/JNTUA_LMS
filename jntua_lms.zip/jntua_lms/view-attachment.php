<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if(!isset($_SESSION["loggedin"])) {
    header("location: index.php");
    exit;
}

// Validate file parameter
if(!isset($_GET['file'])) {
    die("No file specified");
}

$filename = $_GET['file'];

// Validate filename (prevent directory traversal)
if(strpos($filename, '..') !== false || strpos($filename, '/') !== false || strpos($filename, '\\') !== false) {
    die("Invalid file name");
}

$filepath = __DIR__ . '/uploads/' . $filename;

// Check if file exists
if(!file_exists($filepath)) {
    die("File not found");
}

// Validate file extension
$allowed_extensions = ['pdf', 'jpg', 'jpeg', 'png'];
$file_ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
if(!in_array($file_ext, $allowed_extensions)) {
    die("Invalid file type");
}

// Validate file ownership for faculty and admin
if($_SESSION['role'] == 'faculty') {
    $employee_sql = "SELECT id FROM employees WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $employee_sql);
    mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
    mysqli_stmt_execute($stmt);
    $employee_result = mysqli_stmt_get_result($stmt);
    $employee = mysqli_fetch_assoc($employee_result);

    $file_sql = "SELECT COUNT(*) as count FROM leave_applications 
                 WHERE employee_id = ? AND attachment = ?";
    $stmt = mysqli_prepare($conn, $file_sql);
    mysqli_stmt_bind_param($stmt, "is", $employee['id'], $filename);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if($result['count'] == 0) {
        die("You are not authorized to view this file");
    }
}

// Set appropriate headers
switch($file_ext) {
    case 'pdf':
        header('Content-Type: application/pdf');
        break;
    case 'jpg':
    case 'jpeg':
        header('Content-Type: image/jpeg');
        break;
    case 'png':
        header('Content-Type: image/png');
        break;
}

header('Content-Disposition: inline; filename="' . $filename . '"');
header('Content-Length: ' . filesize($filepath));
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Output file contents
readfile($filepath);
exit;
?> 